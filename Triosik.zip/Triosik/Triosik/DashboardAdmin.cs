﻿using System;
using System.Data.SqlClient;
using System.IO;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace Triosik
{
    public partial class DashboardAdmin : Form
    {
        Panel sidebar, contentPanel; string activeMenu = "Dashboard";

        readonly Color Blue = Color.FromArgb(0, 92, 220);
        readonly Color DarkBlue = Color.FromArgb(0, 48, 120);
        readonly Color Bg = Color.FromArgb(245, 249, 255);
        readonly Color Card = Color.White;
        readonly Color TextDark = Color.FromArgb(15, 23, 42);

        const int SidebarW = 250;
        const int MainX = 100;
        const int StatX = 160;
        const int StatY = 160;
        const int TableX = 100;
        const int TableY = 360;
        const int TableW = 1250;
        const int TableH = 520;

        string connString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Triosik;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";

        public DashboardAdmin()
        {
            InitializeComponent();
            BuildUI();
        }

        private void DashboardAdmin_Load(object sender, EventArgs e) { }

        void BuildUI()
        {
            Text = "Triosik Admin";
            FormBorderStyle = FormBorderStyle.None;
            WindowState = FormWindowState.Maximized;
            BackColor = Bg;
            DoubleBuffered = true;
            Controls.Clear();

            sidebar = new Panel();
            sidebar.Location = new Point(0, 0);
            sidebar.Size = new Size(SidebarW, ClientSize.Height);
            sidebar.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            sidebar.BackColor = Blue;
            Controls.Add(sidebar);

            contentPanel = new Panel();
            contentPanel.Location = new Point(SidebarW, 0);
            contentPanel.Size = new Size(ClientSize.Width - SidebarW, ClientSize.Height);
            contentPanel.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            contentPanel.BackColor = Bg;
            Controls.Add(contentPanel);

            Resize += (s, e) =>
            {
                sidebar.Height = ClientSize.Height;
                contentPanel.Location = new Point(SidebarW, 0);
                contentPanel.Size = new Size(ClientSize.Width - SidebarW, ClientSize.Height);
            };

            SetActiveMenu("Dashboard");
            ShowDashboard();
        }

        void SetActiveMenu(string menu)
        {
            activeMenu = menu;
            sidebar.Controls.Clear();

            AddLabel(sidebar, "♪", 35, 30, 34, true, Color.White);
            AddLabel(sidebar, "TRIOSIK", 85, 35, 18, true, Color.White);
            AddLabel(sidebar, "Admin Panel", 86, 65, 10, false, Color.White);

            AddMenu("⌂", "Dashboard", 125, ShowDashboard);
            AddMenu("♫", "Kelola Studio", 200, ShowStudio);
            AddMenu("+", "Kelola Layanan", 275, ShowLayanan);
            AddMenu("▣", "Riwayat Booking", 350, ShowBooking);
            AddMenu("▤", "Riwayat Pembayaran", 425, ShowPembayaran);

            AddLine(sidebar, 25, 510, 200);
            AddMenu("↪", "Logout", 550, Logout);
        }

        void AddMenu(string icon, string text, int y, Action action)
        {
            bool active = activeMenu == text;
            Panel menu = RoundedPanel(215, 52, 12, active ? Color.FromArgb(60, 145, 255) : Blue);
            menu.Location = new Point(17, y);
            menu.Cursor = Cursors.Hand;
            sidebar.Controls.Add(menu);

            AddLabel(menu, icon, 24, 11, 19, true, Color.White);
            AddLabel(menu, text, 68, 15, 10, true, Color.White);

            menu.Click += (s, e) => { SetActiveMenu(text); action(); };
            foreach (Control c in menu.Controls)
                c.Click += (s, e) => { SetActiveMenu(text); action(); };
        }

        void TopBar(string title, string subtitle)
        {
            contentPanel.Controls.Clear();
            AddLabel(contentPanel, title, 100, 50, 24, true, TextDark);
            AddLabel(contentPanel, subtitle, 116, 105, 10, false, Color.FromArgb(90, 103, 125));
        }

        void ShowDashboard()
        {
            TopBar("Welcome Admin! 👋", "Kelola studio musik dengan mudah.");

            AddStatCard(160, 200, "▣", "Total Booking", CountDb("SELECT COUNT(*) FROM Booking").ToString(), "Semua Data", Color.FromArgb(235, 245, 255), Blue);
            AddStatCard(480, 200, "✓", "Booking Selesai", CountDb("SELECT COUNT(*) FROM Booking WHERE status_booking='Selesai'").ToString(), "Selesai", Color.FromArgb(235, 255, 242), Color.Green);
            AddStatCard(800, 200, "◷", "Booking Pending", CountDb("SELECT COUNT(*) FROM Booking WHERE status_pembayaran='Belum Lunas'").ToString(), "Menunggu Kasir", Color.FromArgb(255, 246, 225), Color.Orange);
            AddStatCard(1120, 200, "Rp", "Total Pendapatan", FormatRupiah(CountDb("SELECT ISNULL(SUM(jumlah_bayar),0) FROM Pembayaran")), "Semua", Color.FromArgb(245, 240, 255), Color.FromArgb(90, 70, 220));

            Panel quick = RoundedPanel(1200, 360, 18, Card);
            quick.Location = new Point(200, 440);
            contentPanel.Controls.Add(quick);

            AddLabel(quick, "Akses Cepat", 30, 25, 15, true, TextDark);
            AddQuickCard(quick, 35, 85, "♫", "Kelola Studio", "Tambah, ubah, hapus studio.", ShowStudio);
            AddQuickCard(quick, 285, 85, "+", "Kelola Layanan", "Tambah dan kelola layanan.", ShowLayanan);
            AddQuickCard(quick, 535, 85, "▣", "Riwayat Booking", "Lihat booking dan hapus data.", ShowBooking);
            AddQuickCard(quick, 785, 85, "▤", "Riwayat Pembayaran", "Lihat pembayaran kasir.", ShowPembayaran);
        }

        void ShowBooking()
        {
            TopBar("Riwayat Booking", "Kelola semua data booking studio.");

            Panel box = RoundedPanel(TableW, TableH, 18, Card);
            box.Location = new Point(TableX, 270);
            box.AutoScroll = true;
            contentPanel.Controls.Add(box);

            string[] h = { "ID", "Nama", "Studio", "Tanggal", "Jam", "Total", "Layanan", "Catatan", "Booking", "Bayar", "Aksi" };
            int[] x = { 25, 105, 220, 340, 455, 585, 700, 835, 970, 1070, 1165 };
            AddTableHeader(box, h, x, 45);

            using (SqlConnection conn = new SqlConnection(connString))
            {
                conn.Open();
                string q = @"
                SELECT
                    b.id_booking,
                    b.nama_pemesan,
                    s.nama_studio,
                    b.tanggal,
                    CONVERT(VARCHAR(5), b.jam_mulai, 108) + ' - ' + CONVERT(VARCHAR(5), b.jam_selesai, 108) AS jam,
                    b.total_harga,
                    b.status_booking,
                    b.status_pembayaran,
                    ISNULL(b.catatan, '-') AS catatan,
                    ISNULL(STUFF((
                        SELECT ', ' + l.nama_layanan
                        FROM Booking_Layanan bl
                        INNER JOIN Layanan l ON bl.id_layanan = l.id_layanan
                        WHERE bl.id_booking = b.id_booking
                        FOR XML PATH(''), TYPE
                    ).value('.', 'NVARCHAR(MAX)'), 1, 2, ''), '-') AS layanan
                FROM Booking b
                INNER JOIN Studio s ON b.id_studio = s.id_studio
                ORDER BY b.id_booking DESC";

                SqlCommand cmd = new SqlCommand(q, conn);
                SqlDataReader r = cmd.ExecuteReader();

                int y = 115;
                while (r.Read())
                {
                    int id = Convert.ToInt32(r["id_booking"]);
                    AddBookingRow(box, id, "BK" + id, r["nama_pemesan"].ToString(), r["nama_studio"].ToString(),
                        Convert.ToDateTime(r["tanggal"]).ToString("dd/MM/yy"), r["jam"].ToString(),
                        FormatRupiah(Convert.ToInt32(r["total_harga"])), r["layanan"].ToString(), r["catatan"].ToString(),
                        r["status_booking"].ToString(), r["status_pembayaran"].ToString(), y);
                    y += 65;
                }

                r.Close();
                if (y == 115) AddLabel(box, "Belum ada data booking.", 35, 120, 11, false, Color.Gray);
            }
        }

        void ShowStudio()
        {
            TopBar("Kelola Studio", "Kelola semua studio dan harga sewa.");
            AddButton(contentPanel, "+ Tambah Studio", 1190, 155, 180, 45, Blue, Color.White, (s, e) => ShowStudioForm(0, "", "", 0, "", "Aktif"));

            AddStatCard(StatX, StatY, "▦", "Total Studio", CountDb("SELECT COUNT(*) FROM Studio").ToString(), "Semua Studio", Color.FromArgb(240, 245, 255), Blue);
            AddStatCard(StatX + 330, StatY, "✓", "Studio Aktif", CountDb("SELECT COUNT(*) FROM Studio WHERE status='Aktif'").ToString(), "Ditampilkan", Color.FromArgb(235, 255, 242), Color.Green);
            AddStatCard(StatX + 660, StatY, "□", "Studio Nonaktif", CountDb("SELECT COUNT(*) FROM Studio WHERE status<>'Aktif'").ToString(), "Disembunyikan", Color.FromArgb(255, 246, 225), Color.Orange);

            Panel box = RoundedPanel(TableW, TableH, 18, Card);
            box.Location = new Point(TableX, TableY);
            box.AutoScroll = true;
            contentPanel.Controls.Add(box);

            AddLabel(box, "Daftar Studio", 30, 25, 15, true, TextDark);
            string[] h = { "ID", "Nama Studio", "Jenis", "Harga / Jam", "Foto", "Status", "Aksi" };
            int[] x = { 25, 160, 360, 540, 720, 900, 1080 };
            AddTableHeader(box, h, x, 85);

            using (SqlConnection conn = new SqlConnection(connString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM Studio ORDER BY id_studio", conn);
                SqlDataReader r = cmd.ExecuteReader();

                int y = 150;
                while (r.Read())
                {
                    int id = Convert.ToInt32(r["id_studio"]);
                    AddStudioRow(box, id, "ST" + id.ToString("000"), r["nama_studio"].ToString(),
                        r["jenis_studio"].ToString(), FormatRupiah(Convert.ToInt32(r["harga_per_jam"])),
                        r["foto_studio"].ToString(), r["status"].ToString(), y);
                    y += 70;
                }

                r.Close();
                if (y == 150) AddLabel(box, "Belum ada data studio.", 35, 160, 11, false, Color.Gray);
            }
        }

        void ShowLayanan()
        {
            TopBar("Kelola Layanan", "Kelola layanan tambahan yang tersedia.");
            AddButton(contentPanel, "+ Tambah Layanan", 1175, 155, 195, 45, Blue, Color.White, (s, e) => ShowLayananForm(0, "", 0, "Aktif"));

            AddStatCard(StatX, StatY, "≡", "Total Layanan", CountDb("SELECT COUNT(*) FROM Layanan").ToString(), "Semua Layanan", Color.FromArgb(240, 245, 255), Blue);
            AddStatCard(StatX + 330, StatY, "✓", "Layanan Aktif", CountDb("SELECT COUNT(*) FROM Layanan WHERE status='Aktif'").ToString(), "Ditampilkan", Color.FromArgb(235, 255, 242), Color.Green);
            AddStatCard(StatX + 660, StatY, "□", "Layanan Nonaktif", CountDb("SELECT COUNT(*) FROM Layanan WHERE status<>'Aktif'").ToString(), "Disembunyikan", Color.FromArgb(255, 246, 225), Color.Orange);

            Panel box = RoundedPanel(TableW, TableH, 18, Card);
            box.Location = new Point(TableX, TableY);
            box.AutoScroll = true;
            contentPanel.Controls.Add(box);

            AddLabel(box, "Daftar Layanan", 30, 25, 15, true, TextDark);
            string[] h = { "ID", "Nama Layanan", "Harga", "Status", "Aksi" };
            int[] x = { 25, 220, 520, 760, 980 };
            AddTableHeader(box, h, x, 85);

            using (SqlConnection conn = new SqlConnection(connString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM Layanan ORDER BY id_layanan", conn);
                SqlDataReader r = cmd.ExecuteReader();

                int y = 150;
                while (r.Read())
                {
                    int id = Convert.ToInt32(r["id_layanan"]);
                    AddLayananRow(box, id, "LY" + id.ToString("000"), r["nama_layanan"].ToString(),
                        FormatRupiah(Convert.ToInt32(r["harga"])), r["status"].ToString(), y);
                    y += 70;
                }

                r.Close();
                if (y == 150) AddLabel(box, "Belum ada data layanan.", 35, 160, 11, false, Color.Gray);
            }
        }

        void ShowPembayaran()
        {
            TopBar("Riwayat Pembayaran", "Lihat pembayaran yang sudah dikonfirmasi kasir.");


            int cardY = 160;

            int card1X = 140;
            int card2X = 500;
            int card3X = 860;

            AddStatCard(card1X, cardY, "▦", "Total Transaksi", CountDb("SELECT COUNT(*) FROM Pembayaran").ToString(), "Transaksi", Color.FromArgb(240, 245, 255), Blue);
            AddStatCard(card2X, cardY, "Rp", "Total Pendapatan", FormatRupiah(CountDb("SELECT ISNULL(SUM(jumlah_bayar),0) FROM Pembayaran")), "Total", Color.FromArgb(235, 255, 242), Color.Green);
            AddStatCard(card3X, cardY, "◷", "Menunggu Kasir", CountDb("SELECT COUNT(*) FROM Booking WHERE status_pembayaran='Belum Lunas'").ToString(), "Transaksi", Color.FromArgb(255, 246, 225), Color.Orange);

            Panel box = RoundedPanel(1380, 620, 18, Card);
            box.Location = new Point(130, 380);
            box.AutoScroll = true;
            contentPanel.Controls.Add(box);

            AddLabel(box, "Riwayat Pembayaran", 30, 25, 15, true, TextDark);
            string[] h = { "ID", "Nama", "Studio", "Tanggal", "Jam", "Total", "Layanan", "Catatan", "Metode", "Status" };
            int[] x = { 25, 125, 260, 390, 515, 660, 800, 980, 1140, 1250 };
            AddTableHeader(box, h, x, 85);

            using (SqlConnection conn = new SqlConnection(connString))
            {
                conn.Open();
                string q = @"
                SELECT
                    b.id_booking,
                    b.nama_pemesan,
                    s.nama_studio,
                    p.tanggal_bayar,
                    CONVERT(VARCHAR(5), b.jam_mulai, 108) + ' - ' + CONVERT(VARCHAR(5), b.jam_selesai, 108) AS jam,
                    p.jumlah_bayar,
                    p.metode_pembayaran,
                    p.status_pembayaran,
                    ISNULL(b.catatan, '-') AS catatan,
                    ISNULL(STUFF((
                        SELECT ', ' + l.nama_layanan
                        FROM Booking_Layanan bl
                        INNER JOIN Layanan l ON bl.id_layanan = l.id_layanan
                        WHERE bl.id_booking = b.id_booking
                        FOR XML PATH(''), TYPE
                    ).value('.', 'NVARCHAR(MAX)'), 1, 2, ''), '-') AS layanan
                FROM Pembayaran p
                INNER JOIN Booking b ON p.id_booking = b.id_booking
                INNER JOIN Studio s ON b.id_studio = s.id_studio
                ORDER BY p.tanggal_bayar DESC";

                SqlCommand cmd = new SqlCommand(q, conn);
                SqlDataReader r = cmd.ExecuteReader();

                int y = 150;
                while (r.Read())
                {
                    AddBayarRow(box, "BK" + r["id_booking"], r["nama_pemesan"].ToString(),
                        r["nama_studio"].ToString(), Convert.ToDateTime(r["tanggal_bayar"]).ToString("dd/MM/yy"),
                        r["jam"].ToString(), FormatRupiah(Convert.ToInt32(r["jumlah_bayar"])),
                        r["layanan"].ToString(), r["catatan"].ToString(), r["metode_pembayaran"].ToString(),
                        r["status_pembayaran"].ToString(), y);
                    y += 70;
                }

                r.Close();
                if (y == 150) AddLabel(box, "Belum ada laporan pembayaran.", 35, 160, 11, false, Color.Gray);
            }
        }

        void ShowStudioForm(int id, string nama, string jenis, int harga, string foto, string status)
        {
            Form f = new Form();
            f.Text = id == 0 ? "Tambah Studio" : "Edit Studio";
            f.Size = new Size(520, 430);
            f.StartPosition = FormStartPosition.CenterScreen;
            f.FormBorderStyle = FormBorderStyle.FixedDialog;
            f.MaximizeBox = false;

            int labelX = 45;
            int inputX = 190;
            int inputW = 260;

            TextBox txtNama = MakeTextBox(f, "Nama Studio", nama, labelX, inputX, 45, inputW);
            Label lblJenis = new Label();
            lblJenis.Text = "Jenis Studio";
            lblJenis.Location = new Point(labelX, 110);
            lblJenis.AutoSize = true;
            f.Controls.Add(lblJenis);

            ComboBox cbJenis = new ComboBox();
            cbJenis.Location = new Point(inputX, 105);
            cbJenis.Size = new Size(inputW, 32);
            cbJenis.DropDownStyle = ComboBoxStyle.DropDownList;

            cbJenis.Items.AddRange(new string[]
            {
    "Reguler",
    "VIP",
    "VVIP"
            });

            cbJenis.SelectedItem = string.IsNullOrEmpty(jenis) ? "Reguler" : jenis;

            f.Controls.Add(cbJenis);
            TextBox txtHarga = MakeTextBox(f, "Harga / Jam", harga == 0 ? "" : harga.ToString(), labelX, inputX, 165, inputW);
            TextBox txtFoto = MakeTextBox(f, "Foto Studio", foto, labelX, inputX, 225, 160);

            Button browseFoto = new Button();
            browseFoto.Text = "Pilih Foto";
            browseFoto.Location = new Point(360, 222);
            browseFoto.Size = new Size(90, 32);
            browseFoto.Click += (s, e) =>
            {
                OpenFileDialog ofd = new OpenFileDialog();
                ofd.Title = "Pilih Foto Studio";
                ofd.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp;*.webp";

                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    string folder = Path.Combine(Application.StartupPath, "StudioImages");
                    Directory.CreateDirectory(folder);

                    string fileName = Path.GetFileName(ofd.FileName);
                    string destPath = Path.Combine(folder, fileName);

                    File.Copy(ofd.FileName, destPath, true);
                    txtFoto.Text = fileName;
                }
            };
            f.Controls.Add(browseFoto);

            Label lblStatus = new Label();
            lblStatus.Text = "Status";
            lblStatus.Location = new Point(labelX, 290);
            lblStatus.AutoSize = true;
            f.Controls.Add(lblStatus);

            ComboBox cbStatus = new ComboBox();
            cbStatus.Items.AddRange(new string[] { "Aktif", "Nonaktif" });
            cbStatus.Text = status == "" ? "Aktif" : status;
            cbStatus.Location = new Point(inputX, 285);
            cbStatus.Size = new Size(inputW, 32);
            f.Controls.Add(cbStatus);

            Button save = new Button();
            save.Text = "Simpan";
            save.Location = new Point(340, 345);
            save.Size = new Size(110, 38);

            save.Click += (s, e) =>
            {
                int hargaValue;
                if (txtNama.Text.Trim() == "" || !int.TryParse(txtHarga.Text.Trim(), out hargaValue))
                {
                    MessageBox.Show("Nama wajib diisi dan harga harus angka.");
                    return;
                }

                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();

                    string q = id == 0
                        ? @"INSERT INTO Studio (nama_studio, jenis_studio, harga_per_jam, foto_studio, status)
                    VALUES (@nama, @jenis, @harga, @foto, @status)"
                        : @"UPDATE Studio 
                    SET nama_studio=@nama, jenis_studio=@jenis, harga_per_jam=@harga, foto_studio=@foto, status=@status
                    WHERE id_studio=@id";

                    SqlCommand cmd = new SqlCommand(q, conn);
                    cmd.Parameters.AddWithValue("@nama", txtNama.Text.Trim());
                    cmd.Parameters.AddWithValue("@jenis", cbJenis.Text);
                    cmd.Parameters.AddWithValue("@harga", hargaValue);
                    cmd.Parameters.AddWithValue("@foto", txtFoto.Text.Trim() == "" ? (object)DBNull.Value : txtFoto.Text.Trim());
                    cmd.Parameters.AddWithValue("@status", cbStatus.Text);

                    if (id != 0)
                        cmd.Parameters.AddWithValue("@id", id);

                    cmd.ExecuteNonQuery();
                }

                f.Close();
                ShowStudio();
            };

            f.Controls.Add(save);
            f.ShowDialog();
        }

        void ShowLayananForm(int id, string nama, int harga, string status)
        {
            Form f = new Form();
            f.Text = id == 0 ? "Tambah Layanan" : "Edit Layanan";

            // ATUR UKURAN POPUP DI SINI
            f.Size = new Size(520, 380);

            f.StartPosition = FormStartPosition.CenterScreen;
            f.FormBorderStyle = FormBorderStyle.FixedDialog;
            f.MaximizeBox = false;

            // ATUR POSISI INPUT DI SINI
            int labelX = 45;
            int inputX = 190;
            int inputW = 260;

            TextBox txtNama = MakeTextBox(f, "Nama Layanan", nama, labelX, inputX, 55, inputW);
            TextBox txtHarga = MakeTextBox(f, "Harga", harga == 0 ? "" : harga.ToString(), labelX, inputX, 125, inputW);

            Label lblStatus = new Label();
            lblStatus.Text = "Status";
            lblStatus.Location = new Point(labelX, 198);
            lblStatus.AutoSize = true;
            f.Controls.Add(lblStatus);

            ComboBox cbStatus = new ComboBox();
            cbStatus.Items.AddRange(new string[] { "Aktif", "Nonaktif" });
            cbStatus.Text = status == "" ? "Aktif" : status;

            // ATUR POSISI STATUS DI SINI
            cbStatus.Location = new Point(inputX, 192);
            cbStatus.Size = new Size(inputW, 32);
            f.Controls.Add(cbStatus);

            Button save = new Button();
            save.Text = "Simpan";

            // ATUR POSISI TOMBOL DI SINI
            save.Location = new Point(340, 280);
            save.Size = new Size(110, 38);

            save.Click += (s, e) =>
            {
                int hargaValue;
                if (txtNama.Text.Trim() == "" || !int.TryParse(txtHarga.Text.Trim(), out hargaValue))
                {
                    MessageBox.Show("Nama wajib diisi dan harga harus angka.");
                    return;
                }

                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();

                    string q = id == 0
                        ? @"INSERT INTO Layanan (nama_layanan, harga, status) VALUES (@nama, @harga, @status)"
                        : @"UPDATE Layanan SET nama_layanan=@nama, harga=@harga, status=@status WHERE id_layanan=@id";

                    SqlCommand cmd = new SqlCommand(q, conn);
                    cmd.Parameters.AddWithValue("@nama", txtNama.Text.Trim());
                    cmd.Parameters.AddWithValue("@harga", hargaValue);
                    cmd.Parameters.AddWithValue("@status", cbStatus.Text);

                    if (id != 0)
                        cmd.Parameters.AddWithValue("@id", id);

                    cmd.ExecuteNonQuery();
                }

                f.Close();
                ShowLayanan();
            };

            f.Controls.Add(save);
            f.ShowDialog();
        }

        TextBox MakeTextBox(Form f, string label, string value, int labelX, int inputX, int y, int inputW)
        {
            Label l = new Label();
            l.Text = label;
            l.Location = new Point(labelX, y + 5);
            l.AutoSize = true;
            f.Controls.Add(l);

            TextBox t = new TextBox();
            t.Text = value;
            t.Location = new Point(inputX, y);
            t.Size = new Size(inputW, 32);
            f.Controls.Add(t);

            return t;
        }

        void DeleteStudio(int id)
        {
            if (MessageBox.Show("Yakin hapus studio ini?", "Hapus Studio", MessageBoxButtons.YesNo) != DialogResult.Yes) return;

            try
            {
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("DELETE FROM Studio WHERE id_studio=@id", conn);
                    cmd.Parameters.AddWithValue("@id", id);
                    cmd.ExecuteNonQuery();
                }
                ShowStudio();
            }
            catch
            {
                MessageBox.Show("Studio tidak bisa dihapus karena sudah dipakai booking.\nUbah status jadi Nonaktif aja.");
            }
        }

        void DeleteLayanan(int id)
        {
            if (MessageBox.Show("Yakin hapus layanan ini?", "Hapus Layanan", MessageBoxButtons.YesNo) != DialogResult.Yes) return;

            try
            {
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("DELETE FROM Layanan WHERE id_layanan=@id", conn);
                    cmd.Parameters.AddWithValue("@id", id);
                    cmd.ExecuteNonQuery();
                }
                ShowLayanan();
            }
            catch
            {
                MessageBox.Show("Layanan tidak bisa dihapus karena sudah dipakai booking.\nUbah status jadi Nonaktif aja.");
            }
        }

        void DeleteBooking(int id)
        {
            if (MessageBox.Show("Yakin hapus booking ini?", "Hapus Booking", MessageBoxButtons.YesNo) != DialogResult.Yes) return;

            try
            {
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();
                    SqlCommand c1 = new SqlCommand("DELETE FROM Booking_Layanan WHERE id_booking=@id", conn);
                    c1.Parameters.AddWithValue("@id", id);
                    c1.ExecuteNonQuery();

                    SqlCommand c2 = new SqlCommand("DELETE FROM Pembayaran WHERE id_booking=@id", conn);
                    c2.Parameters.AddWithValue("@id", id);
                    c2.ExecuteNonQuery();

                    SqlCommand c3 = new SqlCommand("DELETE FROM Booking WHERE id_booking=@id", conn);
                    c3.Parameters.AddWithValue("@id", id);
                    c3.ExecuteNonQuery();
                }
                ShowBooking();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Gagal hapus booking:\n" + ex.Message);
            }
        }

        int AmbilHargaStudio(int id)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("SELECT harga_per_jam FROM Studio WHERE id_studio=@id", conn);
                cmd.Parameters.AddWithValue("@id", id);
                return Convert.ToInt32(cmd.ExecuteScalar());
            }
        }

        int AmbilHargaLayanan(int id)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("SELECT harga FROM Layanan WHERE id_layanan=@id", conn);
                cmd.Parameters.AddWithValue("@id", id);
                return Convert.ToInt32(cmd.ExecuteScalar());
            }
        }

        int CountDb(string query)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(query, conn);
                return Convert.ToInt32(cmd.ExecuteScalar());
            }
        }

        string ShortText(string text, int max)
        {
            if (string.IsNullOrWhiteSpace(text)) return "-";
            text = text.Replace("\r", " ").Replace("\n", " ").Trim();
            if (text.Length <= max) return text;
            return text.Substring(0, max - 3) + "...";
        }

        string FormatRupiah(int value)
        {
            return "Rp " + value.ToString("N0").Replace(",", ".");
        }

        void AddBookingRow(Control p, int realId, string id, string nama, string studio, string tgl, string jam, string total, string layanan, string catatan, string status, string bayar, int y)
        {
            AddLabel(p, id, 25, y, 8, false, TextDark);
            AddLabel(p, ShortText(nama, 12), 105, y, 8, false, TextDark);
            AddLabel(p, ShortText(studio, 13), 220, y, 8, false, TextDark);
            AddLabel(p, tgl, 340, y, 8, false, TextDark);
            AddLabel(p, jam, 455, y, 8, false, TextDark);
            AddLabel(p, total, 585, y, 8, false, TextDark);
            AddLabel(p, ShortText(layanan, 16), 700, y, 8, false, TextDark);
            AddLabel(p, ShortText(catatan, 16), 835, y, 8, false, TextDark);
            AddBadge(p, status, 970, y - 5, status == "Selesai" ? Color.Green : status == "Dibooking" ? Blue : Color.Orange);
            AddBadge(p, bayar, 1070, y - 5, bayar == "Lunas" ? Color.Green : Color.Red);
            AddMiniButton(p, "🗑", 1175, y - 7, Color.Red, (s, e) => DeleteBooking(realId));
            AddLine(p, 25, y + 45, 1200);
        }

        void AddStudioRow(Control p, int realId, string id, string nama, string jenis, string harga, string foto, string status, int y)
        {
            AddLabel(p, id, 25, y, 9, false, TextDark);
            AddLabel(p, nama, 160, y, 9, true, TextDark);
            AddLabel(p, jenis, 360, y, 9, false, TextDark);
            AddLabel(p, harga, 540, y, 9, false, TextDark);
            AddLabel(p, foto == "" ? "-" : foto, 720, y, 9, false, TextDark);
            AddBadge(p, status, 900, y - 5, status == "Aktif" ? Color.Green : Color.Orange);
            AddMiniButton(p, "✎", 1100, y - 7, Color.Orange, (s, e) => ShowStudioForm(realId, nama, jenis, AmbilHargaStudio(realId), foto, status));
            AddMiniButton(p, "🗑", 1145, y - 7, Color.Red, (s, e) => DeleteStudio(realId));
            AddLine(p, 25, y + 45, 1200);
        }

        void AddLayananRow(Control p, int realId, string id, string nama, string harga, string status, int y)
        {
            AddLabel(p, id, 25, y, 9, false, TextDark);
            AddLabel(p, nama, 220, y, 9, true, TextDark);
            AddLabel(p, harga, 520, y, 9, false, TextDark);
            AddBadge(p, status, 760, y - 5, status == "Aktif" ? Color.Green : Color.Orange);
            AddMiniButton(p, "✎", 1000, y - 7, Color.Orange, (s, e) => ShowLayananForm(realId, nama, AmbilHargaLayanan(realId), status));
            AddMiniButton(p, "🗑", 1045, y - 7, Color.Red, (s, e) => DeleteLayanan(realId));
            AddLine(p, 25, y + 45, 1200);
        }

        void AddBayarRow(Control p, string id, string nama, string studio, string tgl, string jam, string total, string layanan, string catatan, string metode, string status, int y)
        {
            AddLabel(p, id, 25, y, 9, false, TextDark);
            AddLabel(p, nama, 125, y, 9, false, TextDark);
            AddLabel(p, studio, 260, y, 9, false, TextDark);
            AddLabel(p, tgl, 390, y, 9, false, TextDark);
            AddLabel(p, jam, 515, y, 9, false, TextDark);
            AddLabel(p, total, 660, y, 9, false, TextDark);
            AddLabel(p, ShortText(layanan, 20), 800, y, 9, false, TextDark);
            AddLabel(p, ShortText(catatan, 18), 980, y, 9, false, TextDark);
            AddLabel(p, metode, 1140, y, 9, false, TextDark);
            AddBadge(p, status, 1250, y - 5, status == "Lunas" ? Color.Green : Color.Orange);

            AddLine(p, 25, y + 45, 1300);
        }

        void AddQuickCard(Control parent, int x, int y, string icon, string title, string desc, Action action)
        {
            Panel card = RoundedPanel(215, 200, 15, Color.White);
            card.Location = new Point(x, y);
            card.Cursor = Cursors.Hand;
            parent.Controls.Add(card);
            AddLabel(card, icon, 88, 25, 32, true, Blue);
            AddLabel(card, title, 35, 85, 12, true, TextDark);
            AddLabel(card, desc, 28, 120, 9, false, Color.FromArgb(70, 85, 110));
            AddLabel(card, "→", 175, 155, 22, true, Blue);
            card.Click += (s, e) => { SetActiveMenu(title); action(); };
        }

        void AddStatCard(int x, int y, string icon, string title, string value, string desc, Color bg, Color color)
        {
            Panel card = RoundedPanel(300, 175, 15, Card);
            card.Location = new Point(x, y);
            contentPanel.Controls.Add(card);

            Panel iconBox = RoundedPanel(65, 65, 14, bg);
            iconBox.Location = new Point(22, 30);
            card.Controls.Add(iconBox);

            AddLabel(iconBox, icon, 17, 10, 22, true, color);
            AddLabel(card, title, 105, 30, 10, true, TextDark);
            AddLabel(card, value, 105, 62, value.Length > 6 ? 15 : 22, true, color);
            AddLabel(card, desc, 105, 102, 9, false, Color.FromArgb(90, 103, 125));
        }

        void AddTableHeader(Control p, string[] headers, int[] xs, int y)
        {
            Panel head = new Panel();
            head.BackColor = Color.FromArgb(245, 249, 255);
            head.Location = new Point(25, y);
            head.Size = new Size(1200, 50);
            p.Controls.Add(head);

            for (int i = 0; i < headers.Length; i++)
                AddLabel(head, headers[i], xs[i] - 25, 15, 9, true, TextDark);
        }

        void AddBadge(Control p, string text, int x, int y, Color color)
        {
            Label b = new Label();
            b.Text = text;
            b.Font = new Font("Segoe UI", 8, FontStyle.Bold);
            b.ForeColor = color;
            b.BackColor = Color.FromArgb(235, 245, 240);
            b.TextAlign = ContentAlignment.MiddleCenter;
            b.Location = new Point(x, y);
            b.Size = new Size(90, 27);
            p.Controls.Add(b);
            MakeRounded(b, 8);
        }

        void AddMiniButton(Control p, string text, int x, int y, Color color, EventHandler click)
        {
            Button b = new Button();
            b.Text = text;
            b.Font = new Font("Segoe UI", 8, FontStyle.Bold);
            b.ForeColor = color;
            b.BackColor = Color.White;
            b.FlatStyle = FlatStyle.Flat;
            b.FlatAppearance.BorderColor = color;
            b.Size = new Size(30, 30);
            b.Location = new Point(x, y);
            if (click != null) b.Click += click;
            p.Controls.Add(b);
            MakeRounded(b, 7);
        }

        void AddButton(Control p, string text, int x, int y, int w, int h, Color bg, Color fg, EventHandler click)
        {
            Button b = new Button();
            b.Text = text;
            b.Font = new Font("Segoe UI", 9, FontStyle.Bold);
            b.ForeColor = fg;
            b.BackColor = bg;
            b.FlatStyle = FlatStyle.Flat;
            b.FlatAppearance.BorderSize = 0;
            b.Size = new Size(w, h);
            b.Location = new Point(x, y);
            if (click != null) b.Click += click;
            p.Controls.Add(b);
            MakeRounded(b, 9);
        }

        void Logout()
        {
            Close();
            Form1 login = new Form1();
            login.Show();
        }

        void AddLabel(Control p, string text, int x, int y, int size, bool bold, Color color)
        {
            Label lbl = new Label();
            lbl.Text = text;
            lbl.Font = new Font("Segoe UI", size, bold ? FontStyle.Bold : FontStyle.Regular);
            lbl.ForeColor = color;
            lbl.AutoSize = true;
            lbl.BackColor = Color.Transparent;
            lbl.Location = new Point(x, y);
            p.Controls.Add(lbl);
        }

        void AddLine(Control p, int x, int y, int w)
        {
            Panel line = new Panel();
            line.BackColor = Color.FromArgb(220, 228, 240);
            line.Location = new Point(x, y);
            line.Size = new Size(w, 1);
            p.Controls.Add(line);
        }

        Panel RoundedPanel(int w, int h, int r, Color color)
        {
            Panel p = new Panel();
            p.Size = new Size(w, h);
            p.BackColor = color;
            MakeRounded(p, r);
            return p;
        }

        void MakeRounded(Control c, int r)
        {
            GraphicsPath path = new GraphicsPath();
            path.AddArc(0, 0, r * 2, r * 2, 180, 90);
            path.AddArc(c.Width - r * 2, 0, r * 2, r * 2, 270, 90);
            path.AddArc(c.Width - r * 2, c.Height - r * 2, r * 2, r * 2, 0, 90);
            path.AddArc(0, c.Height - r * 2, r * 2, r * 2, 90, 90);
            path.CloseFigure();
            c.Region = new Region(path);
        }
    }
}