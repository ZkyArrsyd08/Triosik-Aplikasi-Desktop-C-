﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace Triosik
{
    public partial class DashboardKasir : Form
    {
        Panel sidebar, contentPanel;
        string activeMenu = "Dashboard";

        readonly Color Blue = Color.FromArgb(0, 92, 220);
        readonly Color Bg = Color.FromArgb(245, 249, 255);
        readonly Color Card = Color.White;
        readonly Color TextDark = Color.FromArgb(15, 23, 42);
        readonly Color DarkBlue = Color.FromArgb(0, 48, 120);

        const int SidebarW = 250;
        const int MainX = 100;
        const int StatX = 160;
        const int StatY = 165;
        const int TableX = 100;
        const int TableY = 360;
        const int TableW = 1250;
        const int TableH = 560;

        string connString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Triosik;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";

        int selectedBookingId = 0;
        int selectedTotal = 0;
        string selectedNama = "-";
        string selectedStudio = "-";
        string selectedTanggal = "-";
        string selectedJam = "-";
        string selectedLayanan = "-";
        string selectedCatatan = "-";
        TextBox txtBayarManual;

        public DashboardKasir()
        {
            InitializeComponent();
            BuildUI();
        }

        private void DashboardKasir_Load(object sender, EventArgs e) { }

        void BuildUI()
        {
            Text = "Triosik Kasir";
            FormBorderStyle = FormBorderStyle.None;
            WindowState = FormWindowState.Maximized;
            BackColor = Bg;
            DoubleBuffered = true;
            Controls.Clear();

            sidebar = new Panel();
            sidebar.Location = new Point(0, 0);
            sidebar.Size = new Size(SidebarW, ClientSize.Height);
            sidebar.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            sidebar.BackColor = Blue;
            Controls.Add(sidebar);

            contentPanel = new Panel();
            contentPanel.Location = new Point(SidebarW, 0);
            contentPanel.Size = new Size(ClientSize.Width - SidebarW, ClientSize.Height);
            contentPanel.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            contentPanel.BackColor = Bg;
            Controls.Add(contentPanel);

            Resize += (s, e) =>
            {
                sidebar.Height = ClientSize.Height;
                contentPanel.Location = new Point(SidebarW, 0);
                contentPanel.Size = new Size(ClientSize.Width - SidebarW, ClientSize.Height);
            };

            SetActiveMenu("Dashboard");
            ShowDashboard();
        }

        void SetActiveMenu(string menu)
        {
            activeMenu = menu;
            sidebar.Controls.Clear();

            AddLabel(sidebar, "♪", 35, 30, 34, true, Color.White);
            AddLabel(sidebar, "TRIOSIK", 85, 35, 18, true, Color.White);
            AddLabel(sidebar, "Kasir Panel", 86, 65, 10, false, Color.White);

            AddMenu("⌂", "Dashboard", 145, ShowDashboard);
            AddMenu("▣", "Konfirmasi Pembayaran", 225, ShowKonfirmasiPembayaran);
            AddMenu("▤", "Riwayat Pembayaran", 305, ShowRiwayatPembayaran);

            AddLine(sidebar, 25, 415, 200);
            AddMenu("↪", "Logout", 455, Logout);
        }

        void AddMenu(string icon, string text, int y, Action action)
        {
            bool active = activeMenu == text;

            Panel menu = RoundedPanel(215, 55, 12, active ? Color.FromArgb(60, 145, 255) : Blue);
            menu.Location = new Point(17, y);
            menu.Cursor = Cursors.Hand;
            sidebar.Controls.Add(menu);

            AddLabel(menu, icon, 24, 12, 19, true, Color.White);
            AddLabel(menu, text, 68, 16, 10, true, Color.White);

            menu.Click += (s, e) => { SetActiveMenu(text); action(); };

            foreach (Control c in menu.Controls)
                c.Click += (s, e) => { SetActiveMenu(text); action(); };
        }


        void TopBar(string title, string subtitle)
        {
            contentPanel.Controls.Clear();

            AddLabel(contentPanel, title, MainX, 50, 26, true, TextDark);
            AddLabel(contentPanel, subtitle, MainX + 2, 95, 11, false, Color.FromArgb(90, 103, 125));
        }


        void ShowDashboard()
        {
            TopBar("Selamat datang, Kasir! 👋", "Kelola pembayaran dan konfirmasi booking dengan mudah.");

            AddStatCard(StatX, StatY, "▣", "Total Booking Hari Ini", CountTodayBooking().ToString(), "Booking", Color.FromArgb(235, 245, 255), Blue);
            AddStatCard(StatX + 330, StatY, "⌛", "Menunggu Pembayaran", CountBelumLunas().ToString(), "Perlu Konfirmasi", Color.FromArgb(255, 246, 225), Color.Orange);
            AddStatCard(StatX + 660, StatY, "✓", "Pembayaran Lunas", CountLunasToday().ToString(), "Hari Ini", Color.FromArgb(235, 255, 242), Color.Green);
            AddStatCard(StatX + 990, StatY, "Rp", "Total Pendapatan", FormatRupiah(GetPendapatanToday()), "Hari Ini", Color.FromArgb(245, 240, 255), Color.FromArgb(90, 70, 220));

            Panel featureBox = RoundedPanel(TableW, 340, 18, Card);
            featureBox.Location = new Point(TableX, 430);
            contentPanel.Controls.Add(featureBox);

            AddLabel(featureBox, "Fitur Kasir", 35, 30, 17, true, TextDark);

            AddFeatureCard(featureBox, 70, 105, "▣", "Konfirmasi Pembayaran", "Konfirmasi pembayaran booking\ndan update status menjadi lunas.", ShowKonfirmasiPembayaran);
            AddFeatureCard(featureBox, 520, 105, "▤", "Riwayat Pembayaran", "Lihat pembayaran yang sudah\ndikonfirmasi.", ShowRiwayatPembayaran);
        }


        void ShowKonfirmasiPembayaran()
        {
            TopBar("Konfirmasi Pembayaran", "Konfirmasi pembayaran booking dan update status menjadi lunas.");

            AddStatCard(StatX, StatY, "⌛", "Menunggu Konfirmasi", CountBelumLunas().ToString(), "Booking", Color.FromArgb(255, 246, 225), Color.Orange);
            AddStatCard(StatX + 330, StatY, "✓", "Pembayaran Lunas", CountLunasToday().ToString(), "Hari Ini", Color.FromArgb(235, 255, 242), Color.Green);
            AddStatCard(StatX + 660, StatY, "Rp", "Total Pendapatan", FormatRupiah(GetPendapatanToday()), "Hari Ini", Color.FromArgb(245, 240, 255), Color.FromArgb(90, 70, 220));

            Panel tableBox = RoundedPanel(870, TableH, 18, Card);
            tableBox.Location = new Point(TableX, TableY);
            contentPanel.Controls.Add(tableBox);

            AddLabel(tableBox, "Daftar Pembayaran Menunggu", 30, 25, 15, true, TextDark);

            string[] h = { "ID", "Nama", "Studio", "Jam", "Total", "Metode", "Aksi" };
            int[] x = { 30, 125, 270, 405, 520, 645, 755 };
            AddTableHeader(tableBox, h, x, 80, 820);

            LoadBookingBelumLunas(tableBox);

            AddDetailPanel();
        }


        void LoadBookingBelumLunas(Control parent)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                conn.Open();

                string query = @"
                    SELECT TOP 7
                        b.id_booking,
                        b.nama_pemesan,
                        s.nama_studio,
                        CONVERT(VARCHAR(5), b.jam_mulai, 108) + ' - ' + CONVERT(VARCHAR(5), b.jam_selesai, 108) AS jam,
                        b.total_harga,
                        b.metode_pembayaran,
                        b.tanggal,
                        ISNULL(NULLIF(b.catatan, ''), '-') AS catatan,
                        ISNULL(
                            STUFF((
                                SELECT ', ' + l.nama_layanan
                                FROM Booking_Layanan bl
                                INNER JOIN Layanan l ON bl.id_layanan = l.id_layanan
                                WHERE bl.id_booking = b.id_booking
                                FOR XML PATH(''), TYPE
                            ).value('.', 'NVARCHAR(MAX)'), 1, 2, ''),
                        '-') AS layanan
                    FROM Booking b
                    INNER JOIN Studio s ON b.id_studio = s.id_studio
                    WHERE b.status_pembayaran = 'Belum Lunas'
                    AND b.status_booking = 'Dibooking'
                    ORDER BY b.id_booking DESC";

                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataReader reader = cmd.ExecuteReader();

                int y = 145;

                while (reader.Read())
                {
                    int id = Convert.ToInt32(reader["id_booking"]);
                    string nama = reader["nama_pemesan"].ToString();
                    string studio = reader["nama_studio"].ToString();
                    string jam = reader["jam"].ToString();
                    int total = Convert.ToInt32(reader["total_harga"]);
                    string metode = reader["metode_pembayaran"].ToString();
                    string tanggal = Convert.ToDateTime(reader["tanggal"]).ToString("dd/MM/yyyy");
                    string layanan = reader["layanan"].ToString();
                    string catatan = reader["catatan"].ToString();

                    AddKonfirmasiRow(parent, id, nama, studio, jam, total, metode, tanggal, layanan, catatan, y);
                    y += 65;
                }

                reader.Close();

                if (y == 145)
                    AddLabel(parent, "Belum ada pembayaran yang menunggu.", 30, 150, 11, false, Color.Gray);
            }
        }

        void AddKonfirmasiRow(Control p, int id, string nama, string studio, string jam, int total, string metode, string tanggal, string layanan, string catatan, int y)
        {
            AddLabel(p, "BK" + id, 30, y, 9, false, TextDark);
            AddLabel(p, ShortText(nama, 15), 125, y, 9, false, TextDark);
            AddLabel(p, ShortText(studio, 14), 270, y, 9, false, TextDark);
            AddLabel(p, jam, 405, y, 9, false, TextDark);
            AddLabel(p, FormatRupiah(total), 520, y, 9, false, TextDark);
            AddLabel(p, metode, 645, y, 9, false, TextDark);

            AddButton(p, "Pilih", 745, y - 9, 85, 34, Blue, Color.White, (s, e) =>
            {
                selectedBookingId = id;
                selectedNama = nama;
                selectedStudio = studio;
                selectedTanggal = tanggal;
                selectedJam = jam;
                selectedTotal = total;
                selectedLayanan = layanan;
                selectedCatatan = catatan;
                ShowKonfirmasiPembayaran();
            });

            AddLine(p, 25, y + 43, 810);
        }

        void AddDetailPanel()
        {
            // Detail panel dibuat lebih tinggi sedikit biar catatan panjang tidak kepotong
            Panel detail = RoundedPanel(430, 635, 18, Card);
            detail.Location = new Point(TableX + 900, TableY);
            contentPanel.Controls.Add(detail);

            AddLabel(detail, "Detail Booking", 30, 25, 15, true, TextDark);

            if (selectedBookingId == 0)
            {
                Panel info = RoundedPanel(370, 80, 12, Color.FromArgb(225, 238, 255));
                info.Location = new Point(30, 80);
                detail.Controls.Add(info);
                AddLabel(info, "ⓘ Pilih booking dari tabel untuk konfirmasi.", 18, 28, 9, false, DarkBlue);
                return;
            }

            AddDetailText(detail, "ID Booking", "BK" + selectedBookingId, 75);
            AddDetailText(detail, "Nama", selectedNama, 112);
            AddDetailText(detail, "Studio", selectedStudio, 149);
            AddDetailText(detail, "Tanggal", selectedTanggal, 186);
            AddDetailText(detail, "Jam", selectedJam, 223);
            AddDetailText(detail, "Layanan", selectedLayanan, 260);

            // Catatan dikasih area lebih tinggi supaya teks panjang otomatis turun ke bawah
            AddDetailText(detail, "Catatan", selectedCatatan, 297);

            AddDetailText(detail, "Total", FormatRupiah(selectedTotal), 382);

            AddLabel(detail, "Uang Bayar", 30, 430, 10, true, Color.FromArgb(70, 85, 110));

            txtBayarManual = new TextBox();
            txtBayarManual.Text = FormatRupiah(selectedTotal);
            txtBayarManual.Font = new Font("Segoe UI", 12, FontStyle.Bold);
            txtBayarManual.Location = new Point(150, 426);
            txtBayarManual.Size = new Size(250, 32);
            detail.Controls.Add(txtBayarManual);

            bool sedangFormatRupiah = false;
            txtBayarManual.TextChanged += (s, e) =>
            {
                if (sedangFormatRupiah) return;

                string angka = OnlyNumber(txtBayarManual.Text);

                if (angka == "")
                {
                    sedangFormatRupiah = true;
                    txtBayarManual.Text = "";
                    sedangFormatRupiah = false;
                    return;
                }

                int value;
                if (int.TryParse(angka, out value))
                {
                    sedangFormatRupiah = true;
                    txtBayarManual.Text = FormatRupiah(value);
                    txtBayarManual.SelectionStart = txtBayarManual.Text.Length;
                    sedangFormatRupiah = false;
                }
            };

            AddButton(detail, "✓ Konfirmasi Lunas", 30, 500, 370, 45, Color.Green, Color.White, (s, e) =>
            {
                KonfirmasiBookingLunas();
            });

            AddButton(detail, "Batalkan Pesanan", 30, 555, 370, 40, Color.FromArgb(220, 55, 55), Color.White, (s, e) =>
            {
                BatalkanPesanan();
            });
        }

        void KonfirmasiBookingLunas()
        {
            if (selectedBookingId == 0)
            {
                MessageBox.Show("Pilih booking dulu.");
                return;
            }

            int uangBayar;
            if (txtBayarManual == null || !int.TryParse(OnlyNumber(txtBayarManual.Text), out uangBayar))
            {
                MessageBox.Show("Input uang bayar harus angka.");
                return;
            }

            if (uangBayar < selectedTotal)
            {
                MessageBox.Show("Uang bayar kurang.\nTotal: " + FormatRupiah(selectedTotal));
                return;
            }

            int kembalian = uangBayar - selectedTotal;

            DialogResult result = MessageBox.Show(
                "Yakin pembayaran booking BK" + selectedBookingId + " sudah lunas?\n\n" +
                "Total: " + FormatRupiah(selectedTotal) + "\n" +
                "Uang Bayar: " + FormatRupiah(uangBayar) + "\n" +
                "Kembalian: " + FormatRupiah(kembalian),
                "Konfirmasi Pembayaran",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (result != DialogResult.Yes) return;

            using (SqlConnection conn = new SqlConnection(connString))
            {
                conn.Open();

                SqlTransaction trans = conn.BeginTransaction();

                try
                {
                    string updateBooking = @"
                        UPDATE Booking
                        SET status_pembayaran = 'Lunas',
                            status_booking = 'Selesai'
                        WHERE id_booking = @id";

                    SqlCommand cmdUpdate = new SqlCommand(updateBooking, conn, trans);
                    cmdUpdate.Parameters.AddWithValue("@id", selectedBookingId);
                    cmdUpdate.ExecuteNonQuery();

                    string insertPembayaran = @"
                        INSERT INTO Pembayaran
                        (id_booking, jumlah_bayar, metode_pembayaran, status_pembayaran, id_kasir)
                        VALUES
                        (@idbooking, @jumlah, 'Cash', 'Lunas', NULL)";

                    SqlCommand cmdPay = new SqlCommand(insertPembayaran, conn, trans);
                    cmdPay.Parameters.AddWithValue("@idbooking", selectedBookingId);
                    cmdPay.Parameters.AddWithValue("@jumlah", selectedTotal);
                    cmdPay.ExecuteNonQuery();

                    trans.Commit();

                    MessageBox.Show("Pembayaran berhasil dikonfirmasi.\nKembalian: " + FormatRupiah(kembalian));

                    ResetSelectedBooking();
                    ShowKonfirmasiPembayaran();
                }
                catch (Exception ex)
                {
                    trans.Rollback();
                    MessageBox.Show("Gagal konfirmasi pembayaran:\n" + ex.Message);
                }
            }
        }

        void BatalkanPesanan()
        {
            if (selectedBookingId == 0)
            {
                MessageBox.Show("Pilih booking dulu.");
                return;
            }

            DialogResult result = MessageBox.Show(
                "Yakin batalkan booking BK" + selectedBookingId + "?\nJam akan kembali tersedia untuk guest.",
                "Batalkan Pesanan",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning
            );

            if (result != DialogResult.Yes) return;

            using (SqlConnection conn = new SqlConnection(connString))
            {
                conn.Open();

                string q = @"
                    UPDATE Booking
                    SET status_booking = 'Dibatalkan',
                        status_pembayaran = 'Dibatalkan'
                    WHERE id_booking = @id";

                SqlCommand cmd = new SqlCommand(q, conn);
                cmd.Parameters.AddWithValue("@id", selectedBookingId);
                cmd.ExecuteNonQuery();
            }

            MessageBox.Show("Pesanan dibatalkan.");
            ResetSelectedBooking();
            ShowKonfirmasiPembayaran();
        }

        void ResetSelectedBooking()
        {
            selectedBookingId = 0;
            selectedTotal = 0;
            selectedNama = "-";
            selectedStudio = "-";
            selectedTanggal = "-";
            selectedJam = "-";
            selectedLayanan = "-";
            selectedCatatan = "-";
        }

        void ShowRiwayatPembayaran()
        {
            TopBar("Riwayat Pembayaran", "Lihat semua pembayaran yang sudah dikonfirmasi.");

            AddStatCard(StatX, StatY, "▦", "Total Transaksi", CountAllPayment().ToString(), "Transaksi", Color.FromArgb(235, 245, 255), Blue);
            AddStatCard(StatX + 330, StatY, "✓", "Pembayaran Lunas", CountAllPayment().ToString(), "Transaksi", Color.FromArgb(235, 255, 242), Color.Green);
            AddStatCard(StatX + 660, StatY, "Rp", "Total Pendapatan", FormatRupiah(GetAllPendapatan()), "Total", Color.FromArgb(245, 240, 255), Color.FromArgb(90, 70, 220));

            Panel box = RoundedPanel(TableW, TableH, 18, Card);
            box.Location = new Point(TableX, TableY);
            contentPanel.Controls.Add(box);

            AddLabel(box, "Riwayat Pembayaran", 30, 25, 15, true, TextDark);

            string[] h = { "ID", "Nama", "Studio", "Jam", "Total", "Layanan", "Catatan", "Status" };
            int[] x = { 30, 120, 250, 390, 535, 675, 880, 1085 };
            AddTableHeader(box, h, x, 80, 1200);

            LoadRiwayatPembayaran(box);
        }


        void LoadRiwayatPembayaran(Control parent)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                conn.Open();

                string query = @"
                    SELECT TOP 7
                        b.id_booking,
                        b.nama_pemesan,
                        s.nama_studio,
                        CONVERT(VARCHAR(5), b.jam_mulai, 108) + ' - ' + CONVERT(VARCHAR(5), b.jam_selesai, 108) AS jam,
                        p.tanggal_bayar,
                        p.jumlah_bayar,
                        p.metode_pembayaran,
                        p.status_pembayaran,
                        ISNULL(NULLIF(b.catatan, ''), '-') AS catatan,
                        ISNULL(
                            STUFF((
                                SELECT ', ' + l.nama_layanan
                                FROM Booking_Layanan bl
                                INNER JOIN Layanan l ON bl.id_layanan = l.id_layanan
                                WHERE bl.id_booking = b.id_booking
                                FOR XML PATH(''), TYPE
                            ).value('.', 'NVARCHAR(MAX)'), 1, 2, ''),
                        '-') AS layanan
                    FROM Pembayaran p
                    INNER JOIN Booking b ON p.id_booking = b.id_booking
                    INNER JOIN Studio s ON b.id_studio = s.id_studio
                    ORDER BY p.tanggal_bayar DESC";

                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataReader reader = cmd.ExecuteReader();

                int y = 145;

                while (reader.Read())
                {
                    AddRiwayatRow(
                        parent,
                        "BK" + reader["id_booking"].ToString(),
                        reader["nama_pemesan"].ToString(),
                        reader["nama_studio"].ToString(),
                        reader["jam"].ToString(),
                        FormatRupiah(Convert.ToInt32(reader["jumlah_bayar"])),
                        reader["layanan"].ToString(),
                        reader["catatan"].ToString(),
                        reader["status_pembayaran"].ToString(),
                        y
                    );

                    // Row dibuat lebih tinggi supaya catatan panjang bisa turun ke bawah
                    y += 95;
                }

                reader.Close();

                if (y == 145)
                    AddLabel(parent, "Belum ada riwayat pembayaran.", 30, 150, 11, false, Color.Gray);
            }
        }

        int CountTodayBooking()
        {
            return ExecuteScalarInt("SELECT COUNT(*) FROM Booking WHERE tanggal = CAST(GETDATE() AS DATE)");
        }

        int CountBelumLunas()
        {
            return ExecuteScalarInt("SELECT COUNT(*) FROM Booking WHERE status_pembayaran = 'Belum Lunas' AND status_booking = 'Dibooking'");
        }

        int CountLunasToday()
        {
            return ExecuteScalarInt("SELECT COUNT(*) FROM Pembayaran WHERE CAST(tanggal_bayar AS DATE) = CAST(GETDATE() AS DATE)");
        }

        int CountAllPayment()
        {
            return ExecuteScalarInt("SELECT COUNT(*) FROM Pembayaran");
        }

        int GetPendapatanToday()
        {
            return ExecuteScalarInt("SELECT ISNULL(SUM(jumlah_bayar),0) FROM Pembayaran WHERE CAST(tanggal_bayar AS DATE) = CAST(GETDATE() AS DATE)");
        }

        int GetAllPendapatan()
        {
            return ExecuteScalarInt("SELECT ISNULL(SUM(jumlah_bayar),0) FROM Pembayaran");
        }

        int ExecuteScalarInt(string query)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(query, conn);
                return Convert.ToInt32(cmd.ExecuteScalar());
            }
        }


        void AddFeatureCard(Control parent, int x, int y, string icon, string title, string desc, Action action)
        {
            Panel card = RoundedPanel(390, 170, 15, Color.White);
            card.Location = new Point(x, y);
            card.Cursor = Cursors.Hand;
            parent.Controls.Add(card);

            Panel iconBox = RoundedPanel(72, 72, 15, Color.FromArgb(235, 245, 255));
            iconBox.Location = new Point(28, 48);
            card.Controls.Add(iconBox);

            AddLabel(iconBox, icon, 18, 12, 25, true, Blue);
            AddLabel(card, title, 125, 42, 13, true, TextDark);
            AddLabel(card, desc, 125, 80, 10, false, Color.FromArgb(70, 85, 110));
            AddLabel(card, "→", 340, 115, 24, true, Blue);

            card.Click += (s, e) =>
            {
                SetActiveMenu(title);
                action();
            };

            foreach (Control c in card.Controls)
                c.Click += (s, e) =>
                {
                    SetActiveMenu(title);
                    action();
                };
        }


        void AddStatCard(int x, int y, string icon, string title, string value, string desc, Color bg, Color color)
        {
            Panel card = RoundedPanel(300, 175, 15, Card);
            card.Location = new Point(x, y);
            contentPanel.Controls.Add(card);

            Panel iconBox = RoundedPanel(68, 68, 15, bg);
            iconBox.Location = new Point(22, 32);
            card.Controls.Add(iconBox);

            AddLabel(iconBox, icon, 17, 11, 23, true, color);
            AddLabel(card, title, 108, 32, 10, true, TextDark);
            AddLabel(card, value, 108, 65, value.Length > 6 ? 15 : 22, true, color);
            AddLabel(card, desc, 108, 108, 9, false, Color.FromArgb(90, 103, 125));
        }


        void AddRiwayatRow(Control p, string id, string nama, string studio, string jam, string total, string layanan, string catatan, string status, int y)
        {
            AddLabel(p, id, 30, y, 9, false, TextDark);
            AddLabel(p, ShortText(nama, 13), 120, y, 9, false, TextDark);
            AddLabel(p, ShortText(studio, 13), 250, y, 9, false, TextDark);
            AddLabel(p, jam, 390, y, 9, false, TextDark);
            AddLabel(p, total, 535, y, 9, false, TextDark);
            AddLabel(p, ShortText(layanan, 20), 675, y, 9, false, TextDark);

            // Catatan dibuat wrap, bukan dipotong pakai ShortText
            AddWrapLabel(p, catatan, 880, y - 2, 185, 70, 8, false, TextDark);

            AddBadge(p, status, 1085, y - 5, Color.Green);
            AddLine(p, 25, y + 78, 1200);
        }


        void AddDetailText(Control p, string left, string right, int y)
        {
            int valueHeight = left == "Catatan" ? 78 : 34;
            int valueFontSize = left == "Catatan" ? 8 : 10;

            Label lblLeft = new Label();
            lblLeft.Text = left;
            lblLeft.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            lblLeft.ForeColor = Color.FromArgb(70, 85, 110);
            lblLeft.BackColor = Color.Transparent;
            lblLeft.Location = new Point(30, y);
            lblLeft.Size = new Size(130, valueHeight);
            lblLeft.TextAlign = ContentAlignment.TopLeft;
            p.Controls.Add(lblLeft);

            Label titik = new Label();
            titik.Text = ":";
            titik.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            titik.ForeColor = TextDark;
            titik.BackColor = Color.Transparent;
            titik.Location = new Point(175, y);
            titik.Size = new Size(20, 30);
            p.Controls.Add(titik);

            Label lblRight = new Label();
            lblRight.Text = string.IsNullOrWhiteSpace(right) ? "-" : right;
            lblRight.Font = new Font("Segoe UI", valueFontSize, FontStyle.Regular);
            lblRight.ForeColor = TextDark;
            lblRight.BackColor = Color.Transparent;
            lblRight.Location = new Point(200, y);
            lblRight.Size = new Size(205, valueHeight);
            lblRight.TextAlign = ContentAlignment.TopLeft;
            lblRight.AutoEllipsis = false;
            p.Controls.Add(lblRight);
        }


        void AddTableHeader(Control p, string[] headers, int[] xs, int y, int width)
        {
            Panel head = new Panel();
            head.BackColor = Color.FromArgb(245, 249, 255);
            head.Location = new Point(25, y);
            head.Size = new Size(width, 52);
            p.Controls.Add(head);

            for (int i = 0; i < headers.Length; i++)
                AddLabel(head, headers[i], xs[i] - 25, 16, 9, true, TextDark);
        }


        void AddBadge(Control p, string text, int x, int y, Color color)
        {
            Label b = new Label();
            b.Text = text;
            b.Font = new Font("Segoe UI", 9, FontStyle.Bold);
            b.ForeColor = color;
            b.BackColor = Color.FromArgb(235, 245, 240);
            b.TextAlign = ContentAlignment.MiddleCenter;
            b.Location = new Point(x, y);
            b.Size = new Size(95, 30);
            p.Controls.Add(b);
            MakeRounded(b, 8);
        }


        void AddButton(Control p, string text, int x, int y, int w, int h, Color bg, Color fg, EventHandler click)
        {
            Button b = new Button();
            b.Text = text;
            b.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            b.ForeColor = fg;
            b.BackColor = bg;
            b.FlatStyle = FlatStyle.Flat;
            b.FlatAppearance.BorderSize = 0;
            b.Size = new Size(w, h);
            b.Location = new Point(x, y);
            b.Cursor = Cursors.Hand;
            if (click != null) b.Click += click;
            p.Controls.Add(b);
            MakeRounded(b, 9);
        }

        void Logout()
        {
            Close();
            DashboardGuest login = new DashboardGuest();
            login.Show();
        }

        string ShortText(string text, int max)
        {
            if (string.IsNullOrWhiteSpace(text)) return "-";
            return text.Length <= max ? text : text.Substring(0, max - 3) + "...";
        }

        string FormatRupiah(int value)
        {
            return "Rp " + value.ToString("N0").Replace(",", ".");
        }

        string OnlyNumber(string text)
        {
            string result = "";

            foreach (char c in text)
            {
                if (char.IsDigit(c))
                    result += c;
            }

            return result;
        }

        void AddWrapLabel(Control p, string text, int x, int y, int w, int h, int size, bool bold, Color color)
        {
            Label lbl = new Label();
            lbl.Text = string.IsNullOrWhiteSpace(text) ? "-" : text;
            lbl.Font = new Font("Segoe UI", size, bold ? FontStyle.Bold : FontStyle.Regular);
            lbl.ForeColor = color;
            lbl.BackColor = Color.Transparent;
            lbl.Location = new Point(x, y);
            lbl.Size = new Size(w, h);
            lbl.TextAlign = ContentAlignment.TopLeft;
            lbl.AutoEllipsis = false;
            p.Controls.Add(lbl);
        }

        void AddLabel(Control p, string text, int x, int y, int size, bool bold, Color color)
        {
            Label lbl = new Label();
            lbl.Text = text;
            lbl.Font = new Font("Segoe UI", size, bold ? FontStyle.Bold : FontStyle.Regular);
            lbl.ForeColor = color;
            lbl.AutoSize = true;
            lbl.BackColor = Color.Transparent;
            lbl.Location = new Point(x, y);
            p.Controls.Add(lbl);
        }

        void AddLine(Control p, int x, int y, int w)
        {
            Panel line = new Panel();
            line.BackColor = Color.FromArgb(220, 228, 240);
            line.Location = new Point(x, y);
            line.Size = new Size(w, 1);
            p.Controls.Add(line);
        }

        Panel RoundedPanel(int w, int h, int r, Color color)
        {
            Panel p = new Panel();
            p.Size = new Size(w, h);
            p.BackColor = color;
            MakeRounded(p, r);
            return p;
        }

        void MakeRounded(Control c, int r)
        {
            GraphicsPath path = new GraphicsPath();
            path.AddArc(0, 0, r * 2, r * 2, 180, 90);
            path.AddArc(c.Width - r * 2, 0, r * 2, r * 2, 270, 90);
            path.AddArc(c.Width - r * 2, c.Height - r * 2, r * 2, r * 2, 0, 90);
            path.AddArc(0, c.Height - r * 2, r * 2, r * 2, 90, 90);
            path.CloseFigure();
            c.Region = new Region(path);
        }
    }
}