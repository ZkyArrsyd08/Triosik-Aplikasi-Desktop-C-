﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;

namespace Triosik
{
    public partial class DashboardGuest : Form
    {
        Panel wrapperPanel;

        string connString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Triosik;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";

        int selectedStudioId = 0;
        string selectedStudioName = "";
        string selectedStudioJenis = "";
        int selectedStudioHarga = 0;
        string selectedStudioFoto = "";

        readonly Color BlueTop = Color.FromArgb(25, 121, 221);
        readonly Color BlueBottom = Color.FromArgb(235, 244, 255);
        readonly Color CardBlue = Color.FromArgb(32, 123, 235);
        readonly Color Yellow = Color.FromArgb(255, 226, 62);
        readonly Color DarkBlue = Color.FromArgb(0, 58, 140);
        readonly Color SelectedGray = Color.FromArgb(170, 170, 170);
        readonly Color DisabledGray = Color.FromArgb(200, 200, 200);

        List<string> selectedTimes = new List<string>();
        HashSet<string> bookedTimes = new HashSet<string>();
        HashSet<string> holdTimes = new HashSet<string>();
        List<string> selectedServices = new List<string>();
        List<int> selectedServiceIds = new List<int>();
        string selectedNote = "";

        Dictionary<string, int> serviceIdByName = new Dictionary<string, int>();
        Dictionary<string, int> servicePriceByName = new Dictionary<string, int>();

        TextBox noteBoxInput;
        Panel buatPesananButton;
        Label buatPesananText;

        public DashboardGuest()
        {
            InitializeComponent();
            LoadServices();
            BuildUI();
        }

        private void DashboardGuest_Load(object sender, EventArgs e) { }

        void BuildUI()
        {
            Text = "Dashboard Guest";
            FormBorderStyle = FormBorderStyle.None;
            WindowState = FormWindowState.Maximized;
            BackColor = BlueBottom;
            DoubleBuffered = true;

            Controls.Clear();

            wrapperPanel = new Panel();
            wrapperPanel.Dock = DockStyle.Fill;
            wrapperPanel.BackColor = Color.Transparent;
            Controls.Add(wrapperPanel);

            ShowDashboardAwal();
        }

        void LoadServices()
        {
            serviceIdByName.Clear();
            servicePriceByName.Clear();

            using (SqlConnection conn = new SqlConnection(connString))
            {
                conn.Open();

                SqlCommand cmd = new SqlCommand("SELECT * FROM Layanan WHERE status='Aktif' ORDER BY id_layanan", conn);
                SqlDataReader r = cmd.ExecuteReader();

                while (r.Read())
                {
                    string nama = r["nama_layanan"].ToString();
                    int id = Convert.ToInt32(r["id_layanan"]);
                    int harga = Convert.ToInt32(r["harga"]);

                    serviceIdByName[nama] = id;
                    servicePriceByName[nama] = harga;
                }

                r.Close();
            }
        }

        void ShowDashboardAwal()
        {
            wrapperPanel.Controls.Clear();

            Panel bg = CreateGradientBackground();
            wrapperPanel.Controls.Add(bg);

            Label back = CreateBackButton();
            back.Click += (s, e) => Logout();
            bg.Controls.Add(back);

            AddSparkle(bg, 555, 105, 60);
            AddSparkle(bg, 1270, 310, 60);

            AddPic(bg, Properties.Resources.Hitam, 605, 190, 190, 190);
            AddPic(bg, Properties.Resources.Kuning, 825, 70, 270, 270);
            AddPic(bg, Properties.Resources.Pink, 1100, 190, 190, 190);

            Label title = new Label();
            title.Text = "Welcome To Our\nMusic Studio";
            title.Font = SafeFont("Chubby And Groovy", 76, FontStyle.Bold);
            title.ForeColor = Color.White;
            title.BackColor = Color.Transparent;
            title.TextAlign = ContentAlignment.MiddleCenter;
            title.Size = new Size(800, 180);
            title.Location = new Point(570, 400);
            bg.Controls.Add(title);

            Panel btn = RoundedPanel(430, 95, 24, Yellow);
            btn.Location = new Point(745, 650);
            btn.Cursor = Cursors.Hand;
            btn.Click += (s, e) => ShowPilihStudio();
            bg.Controls.Add(btn);

            Label btnText = new Label();
            btnText.Text = "Booking Sekarang";
            btnText.Font = SafeFont("Chubby And Groovy", 34, FontStyle.Bold);
            btnText.ForeColor = DarkBlue;
            btnText.BackColor = Color.Transparent;
            btnText.TextAlign = ContentAlignment.MiddleCenter;
            btnText.Dock = DockStyle.Fill;
            btnText.Cursor = Cursors.Hand;
            btnText.Click += (s, e) => ShowPilihStudio();
            btn.Controls.Add(btnText);
        }

        void ShowPilihStudio()
        {
            wrapperPanel.Controls.Clear();

            Panel bg = CreateGradientBackground();
            wrapperPanel.Controls.Add(bg);

            Label back = CreateBackButton();
            back.Click += (s, e) => ShowDashboardAwal();
            bg.Controls.Add(back);

            Label title = new Label();
            title.Text = "Pilih Studio";
            title.Font = SafeFont("Chubby And Groovy", 70, FontStyle.Bold);
            title.ForeColor = DarkBlue;
            title.BackColor = Color.Transparent;
            title.TextAlign = ContentAlignment.MiddleCenter;
            title.Size = new Size(700, 110);
            title.Location = new Point(610, 45);
            bg.Controls.Add(title);

            List<StudioData> studios = GetActiveStudios();

            if (studios.Count == 0)
            {
                Label empty = new Label();
                empty.Text = "Belum ada studio aktif.";
                empty.Font = new Font("Arial", 28, FontStyle.Bold);
                empty.ForeColor = DarkBlue;
                empty.BackColor = Color.Transparent;
                empty.AutoSize = true;
                empty.Location = new Point(730, 360);
                bg.Controls.Add(empty);
                return;
            }

            Panel scrollPanel = new Panel();
            scrollPanel.Location = new Point(70, 170);
            scrollPanel.Size = new Size(1780, 850);
            scrollPanel.BackColor = Color.Transparent;
            scrollPanel.AutoScroll = true;
            scrollPanel.TabStop = true;
            scrollPanel.MouseEnter += (s, e) => scrollPanel.Focus();
            bg.Controls.Add(scrollPanel);
            scrollPanel.BringToFront();
            back.BringToFront();
            title.BringToFront();

            int cardW = 380;
            int cardH = 700;
            int gapX = 45;
            int gapY = 45;
            int cols = Math.Min(4, studios.Count);
            int totalW = (cols * cardW) + ((cols - 1) * gapX);
            int startX = Math.Max(20, (scrollPanel.Width - totalW - 40) / 2);
            int startY = 20;

            for (int i = 0; i < studios.Count; i++)
            {
                int col = i % 4;
                int row = i / 4;

                int x = startX + col * (cardW + gapX);
                int y = startY + row * (cardH + gapY);

                AddStudioCard(scrollPanel, x, y, cardW, cardH, studios[i]);
            }

            int totalRows = (int)Math.Ceiling(studios.Count / 4.0);
            Panel bottomSpace = new Panel();
            bottomSpace.Location = new Point(1, startY + totalRows * (cardH + gapY) + 20);
            bottomSpace.Size = new Size(1, 1);
            bottomSpace.BackColor = Color.Transparent;
            scrollPanel.Controls.Add(bottomSpace);
        }

        List<StudioData> GetActiveStudios()
        {
            List<StudioData> studios = new List<StudioData>();

            using (SqlConnection conn = new SqlConnection(connString))
            {
                conn.Open();

                SqlCommand cmd = new SqlCommand(
                    "SELECT id_studio, nama_studio, jenis_studio, harga_per_jam, foto_studio, status FROM Studio WHERE status='Aktif' ORDER BY id_studio",
                    conn
                );

                SqlDataReader r = cmd.ExecuteReader();

                while (r.Read())
                {
                    StudioData st = new StudioData();
                    st.Id = Convert.ToInt32(r["id_studio"]);
                    st.Nama = r["nama_studio"].ToString();
                    st.Jenis = r["jenis_studio"].ToString();
                    st.Harga = Convert.ToInt32(r["harga_per_jam"]);
                    st.Foto = r["foto_studio"] == DBNull.Value ? "" : r["foto_studio"].ToString();
                    studios.Add(st);
                }

                r.Close();
            }

            return studios;
        }

        void AddStudioCard(Control parent, int x, int y, int w, int h, StudioData studio)
        {
            Panel shadow = RoundedPanel(w, h, 35, Color.White);
            shadow.Location = new Point(x - 12, y + 12);
            parent.Controls.Add(shadow);

            Panel card = RoundedPanel(w, h, 35, CardBlue);
            card.Location = new Point(x, y);
            card.Cursor = Cursors.Hand;
            card.Click += (s, e) => PilihStudio(studio);
            parent.Controls.Add(card);
            card.BringToFront();

            Panel imgBox = RoundedPanel(w - 50, 390, 28, Color.FromArgb(30, 30, 30));
            imgBox.Location = new Point(25, 28);
            imgBox.Cursor = Cursors.Hand;
            imgBox.Click += (s, e) => PilihStudio(studio);
            card.Controls.Add(imgBox);

            PictureBox studioPic = new PictureBox();
            studioPic.Dock = DockStyle.Fill;
            studioPic.SizeMode = PictureBoxSizeMode.StretchImage;
            studioPic.Image = LoadStudioImage(studio.Foto);
            studioPic.BackColor = Color.FromArgb(30, 30, 30);
            studioPic.Cursor = Cursors.Hand;
            studioPic.Click += (s, e) => PilihStudio(studio);
            imgBox.Controls.Add(studioPic);

            Label name = new Label();
            name.Text = studio.Nama;
            name.Font = SafeFont("Chubby And Groovy", studio.Nama.Length > 12 ? 36 : 48, FontStyle.Bold);
            name.ForeColor = Color.White;
            name.BackColor = Color.Transparent;
            name.TextAlign = ContentAlignment.MiddleCenter;
            name.Size = new Size(w - 30, 140);
            name.Location = new Point(15, 440);
            name.Cursor = Cursors.Hand;
            name.Click += (s, e) => PilihStudio(studio);
            card.Controls.Add(name);

            Label jenis = new Label();
            jenis.Text = "(" + studio.Jenis + ")";
            jenis.Font = new Font("Georgia", 17, FontStyle.Bold);
            jenis.ForeColor = Color.White;
            jenis.BackColor = Color.Transparent;
            jenis.TextAlign = ContentAlignment.MiddleCenter;
            jenis.Size = new Size(w - 40, 35);
            jenis.Location = new Point(20, 600);
            jenis.Cursor = Cursors.Hand;
            jenis.Click += (s, e) => PilihStudio(studio);
            card.Controls.Add(jenis);
        }

        Image LoadStudioImage(string foto)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(foto))
                    return Properties.Resources.Studio1;

                string path = foto;

                if (!Path.IsPathRooted(path))
                    path = Path.Combine(Application.StartupPath, "StudioImages", foto);

                if (File.Exists(path))
                    return Image.FromFile(path);

                if (foto == "Studio1") return Properties.Resources.Studio1;
                if (foto == "Studio2") return Properties.Resources.Studio2;
                if (foto == "StudioUtama") return Properties.Resources.StudioUtama;

                return Properties.Resources.Studio1;
            }
            catch
            {
                return Properties.Resources.Studio1;
            }
        }

        void PilihStudio(StudioData studio)
        {
            ResetPilihanBooking();

            selectedStudioId = studio.Id;
            selectedStudioName = studio.Nama;
            selectedStudioJenis = studio.Jenis;
            selectedStudioHarga = studio.Harga;
            selectedStudioFoto = studio.Foto;

            ShowStudioFormPage();
        }

        void ShowStudioFormPage()
        {
            wrapperPanel.Controls.Clear();

            Panel bg = CreateGradientBackground();
            wrapperPanel.Controls.Add(bg);

            Label back = CreateBackButton();
            back.ForeColor = Color.White;
            back.Click += (s, e) => ShowPilihStudio();
            bg.Controls.Add(back);

            AddHeaderStudio(bg);

            Panel formBox = RoundedPanel(1450, 630, 55, Color.FromArgb(214, 231, 250));
            formBox.Location = new Point(220, 310);
            bg.Controls.Add(formBox);

            AddInputRow(formBox, 60, 50, "Today\n" + GetTodayDayOnly(), "Tanggal", false, null);
            AddInputRowImage(formBox, 60, 190, Properties.Resources.Jam, "Pilih Waktu", true, ShowPilihWaktu);
            AddInputRowImage(formBox, 60, 330, Properties.Resources.Layanan, "Pilih Layanan Tambahan (Opsional)", true, ShowPilihLayanan);
            AddInputRowImage(formBox, 60, 470, Properties.Resources.Pensil, "Catatan (Opsional)", true, ShowCatatan);

            AddBuatPesananButton(bg);
        }

        void LoadBookedTimes()
        {
            bookedTimes.Clear();
            holdTimes.Clear();

            if (selectedStudioId <= 0) return;

            using (SqlConnection conn = new SqlConnection(connString))
            {
                conn.Open();

                string query = @"
                    SELECT 
                        jam_mulai,
                        jam_selesai,
                        status_booking,
                        status_pembayaran
                    FROM Booking
                    WHERE id_studio = @idstudio
                    AND tanggal = @tanggal
                    AND ISNULL(status_booking, '') <> 'Dibatalkan'
                    AND ISNULL(status_pembayaran, '') <> 'Dibatalkan'";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@idstudio", selectedStudioId);
                cmd.Parameters.AddWithValue("@tanggal", DateTime.Today);

                SqlDataReader r = cmd.ExecuteReader();

                while (r.Read())
                {
                    TimeSpan mulai = ParseDbTime(r["jam_mulai"]);
                    TimeSpan selesai = ParseDbTime(r["jam_selesai"]);

                    string statusBooking = r["status_booking"].ToString();
                    string statusPembayaran = r["status_pembayaran"].ToString();

                    bool sudahLunas =
                        statusBooking == "Selesai" ||
                        statusPembayaran == "Lunas";

                    bool masihHold =
                        statusBooking == "Dibooking" ||
                        statusPembayaran == "Belum Lunas";

                    for (TimeSpan jam = mulai; jam < selesai; jam = jam.Add(TimeSpan.FromHours(1)))
                    {
                        string jamText = jam.ToString(@"hh\:mm");

                        if (sudahLunas)
                        {
                            if (!bookedTimes.Contains(jamText))
                                bookedTimes.Add(jamText);
                        }
                        else if (masihHold)
                        {
                            if (!holdTimes.Contains(jamText))
                                holdTimes.Add(jamText);
                        }
                    }
                }

                r.Close();
            }
        }

        TimeSpan ParseDbTime(object value)
        {
            if (value is TimeSpan)
                return (TimeSpan)value;

            DateTime dt;
            if (DateTime.TryParse(value.ToString(), out dt))
                return dt.TimeOfDay;

            return TimeSpan.Parse(value.ToString());
        }

        void ShowPilihWaktu(object sender, EventArgs e)
        {
            wrapperPanel.Controls.Clear();

            Panel bg = CreateGradientBackground();
            wrapperPanel.Controls.Add(bg);

            Label back = CreateBackButton();
            back.ForeColor = Color.White;
            back.Click += (s, ev) => ShowStudioFormPage();
            bg.Controls.Add(back);

            AddHeaderStudio(bg);

            Panel formBox = RoundedPanel(1450, 630, 55, Color.FromArgb(214, 231, 250));
            formBox.Location = new Point(220, 310);
            bg.Controls.Add(formBox);

            AddInputRow(formBox, 60, 50, "Today\n" + GetTodayDayOnly(), "Tanggal", false, null);

            Panel waktuBox = RoundedPanel(1310, 390, 30, Color.WhiteSmoke);
            waktuBox.Location = new Point(60, 190);
            formBox.Controls.Add(waktuBox);

            AddDropdownHeaderImage(waktuBox, Properties.Resources.Jam, "Pilih Waktu");

            LoadBookedTimes();

            AddTimeButton(waktuBox, "09:00", 95, 125);
            AddTimeButton(waktuBox, "10:00", 370, 125);
            AddTimeButton(waktuBox, "11:00", 645, 125);
            AddTimeButton(waktuBox, "12:00", 920, 125);
            AddTimeButton(waktuBox, "13:00", 95, 190);
            AddTimeButton(waktuBox, "14:00", 370, 190);
            AddTimeButton(waktuBox, "15:00", 645, 190);
            AddTimeButton(waktuBox, "16:00", 920, 190);
            AddTimeButton(waktuBox, "17:00", 95, 255);
            AddTimeButton(waktuBox, "18:00", 370, 255);
            AddTimeButton(waktuBox, "19:00", 645, 255);
            AddTimeButton(waktuBox, "20:00", 920, 255);
            AddTimeButton(waktuBox, "21:00", 95, 320);

            AddSimpanButton(bg);
        }


        void ShowPilihLayanan(object sender, EventArgs e)
        {
            wrapperPanel.Controls.Clear();

            // refresh layanan setiap halaman dibuka, jadi kalau admin baru nambah layanan langsung kebaca
            LoadServices();

            Panel bg = CreateGradientBackground();
            wrapperPanel.Controls.Add(bg);

            Label back = CreateBackButton();
            back.ForeColor = Color.White;
            back.Click += (s, ev) => ShowStudioFormPage();
            bg.Controls.Add(back);

            AddHeaderStudio(bg);

            Panel formBox = RoundedPanel(1450, 630, 55, Color.FromArgb(214, 231, 250));
            formBox.Location = new Point(220, 310);
            bg.Controls.Add(formBox);

            AddInputRow(formBox, 60, 50, "Today\n" + GetTodayDayOnly(), "Tanggal", false, null);

            Panel layananBox = RoundedPanel(1310, 390, 30, Color.WhiteSmoke);
            layananBox.Location = new Point(60, 190);
            formBox.Controls.Add(layananBox);

            AddDropdownHeaderImage(layananBox, Properties.Resources.Layanan, "Pilih Layanan Tambahan (Opsional)");

            LoadLayananTambahan(layananBox);

            AddSimpanButton(bg);
        }

        void LoadLayananTambahan(Control parent)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                conn.Open();

                string query = "SELECT id_layanan, nama_layanan, harga FROM Layanan WHERE status = 'Aktif' ORDER BY id_layanan";

                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataReader r = cmd.ExecuteReader();

                int x = 95;
                int y = 120;
                int count = 0;

                while (r.Read())
                {
                    int id = Convert.ToInt32(r["id_layanan"]);
                    string nama = r["nama_layanan"].ToString();
                    int harga = Convert.ToInt32(r["harga"]);

                    AddServiceButtonDynamic(parent, id, nama, harga, x, y);

                    x += 395;
                    count++;

                    if (count % 3 == 0)
                    {
                        x = 95;
                        y += 115;
                    }
                }

                r.Close();

                if (count == 0)
                {
                    Label empty = new Label();
                    empty.Text = "Belum ada layanan aktif.";
                    empty.Font = new Font("Arial", 22, FontStyle.Bold);
                    empty.ForeColor = Color.Gray;
                    empty.BackColor = Color.Transparent;
                    empty.AutoSize = true;
                    empty.Location = new Point(95, 140);
                    parent.Controls.Add(empty);
                }
            }
        }

        void AddServiceButtonDynamic(Control parent, int id, string serviceName, int price, int x, int y)
        {
            Panel serviceBtn = RoundedPanel(345, 105, 25,
                selectedServiceIds.Contains(id) ? SelectedGray : CardBlue);

            serviceBtn.Location = new Point(x, y);
            serviceBtn.Cursor = Cursors.Hand;
            parent.Controls.Add(serviceBtn);

            Label name = new Label();
            name.Text = serviceName;
            name.Font = new Font("Arial", 24, FontStyle.Bold);
            name.ForeColor = Color.White;
            name.BackColor = Color.Transparent;
            name.TextAlign = ContentAlignment.MiddleCenter;
            name.Size = new Size(345, 55);
            name.Location = new Point(0, 12);
            name.Cursor = Cursors.Hand;
            serviceBtn.Controls.Add(name);

            Label priceLbl = new Label();
            priceLbl.Text = FormatRupiah(price) + "/jam";
            priceLbl.Font = new Font("Arial", 16, FontStyle.Regular);
            priceLbl.ForeColor = Color.White;
            priceLbl.BackColor = Color.Transparent;
            priceLbl.TextAlign = ContentAlignment.MiddleCenter;
            priceLbl.Size = new Size(345, 35);
            priceLbl.Location = new Point(0, 60);
            priceLbl.Cursor = Cursors.Hand;
            serviceBtn.Controls.Add(priceLbl);

            EventHandler clickAction = (s, e) =>
            {
                if (selectedServiceIds.Contains(id))
                {
                    selectedServiceIds.Remove(id);
                    selectedServices.Remove(serviceName);
                    serviceBtn.BackColor = CardBlue;
                }
                else
                {
                    selectedServiceIds.Add(id);
                    selectedServices.Add(serviceName);

                    serviceIdByName[serviceName] = id;
                    servicePriceByName[serviceName] = price;

                    serviceBtn.BackColor = SelectedGray;
                }
            };

            serviceBtn.Click += clickAction;
            name.Click += clickAction;
            priceLbl.Click += clickAction;
        }

        void ShowCatatan(object sender, EventArgs e)
        {
            wrapperPanel.Controls.Clear();

            Panel bg = CreateGradientBackground();
            wrapperPanel.Controls.Add(bg);

            Label back = CreateBackButton();
            back.ForeColor = Color.White;
            back.Click += (s, ev) => ShowStudioFormPage();
            bg.Controls.Add(back);

            AddHeaderStudio(bg);

            Panel formBox = RoundedPanel(1450, 630, 55, Color.FromArgb(214, 231, 250));
            formBox.Location = new Point(220, 310);
            bg.Controls.Add(formBox);

            Panel catatanBox = RoundedPanel(1310, 530, 30, Color.WhiteSmoke);
            catatanBox.Location = new Point(60, 50);
            formBox.Controls.Add(catatanBox);

            AddDropdownHeaderImage(catatanBox, Properties.Resources.Pensil, "Catatan (Opsional)");

            Panel inputBorder = RoundedPanel(1200, 380, 25, Color.FromArgb(125, 170, 240));
            inputBorder.Location = new Point(55, 115);
            catatanBox.Controls.Add(inputBorder);

            noteBoxInput = new TextBox();
            noteBoxInput.Text = selectedNote == "" ? "Tinggalkan pesan" : selectedNote;
            noteBoxInput.Font = new Font("Arial", 22, FontStyle.Bold);
            noteBoxInput.ForeColor = DarkBlue;
            noteBoxInput.BackColor = Color.WhiteSmoke;
            noteBoxInput.BorderStyle = BorderStyle.None;
            noteBoxInput.Multiline = true;
            noteBoxInput.Size = new Size(1120, 320);
            noteBoxInput.Location = new Point(40, 30);

            noteBoxInput.GotFocus += (s, ev) =>
            {
                if (noteBoxInput.Text == "Tinggalkan pesan")
                    noteBoxInput.Text = "";
            };

            noteBoxInput.LostFocus += (s, ev) =>
            {
                if (noteBoxInput.Text.Trim() == "")
                    noteBoxInput.Text = "Tinggalkan pesan";
            };

            inputBorder.Controls.Add(noteBoxInput);

            AddSimpanButton(bg);
        }

        void AddHeaderStudio(Control bg)
        {
            Panel iconBox = RoundedPanel(220, 190, 45, DarkBlue);
            iconBox.Location = new Point(220, 90);
            bg.Controls.Add(iconBox);

            PictureBox studioIcon = new PictureBox();
            studioIcon.Image = LoadStudioImage(selectedStudioFoto);
            studioIcon.SizeMode = PictureBoxSizeMode.Zoom;
            studioIcon.Size = new Size(150, 140);
            studioIcon.Location = new Point(35, 25);
            studioIcon.BackColor = Color.Transparent;
            iconBox.Controls.Add(studioIcon);

            Label title = new Label();
            title.Text = selectedStudioName;
            title.Font = SafeFont("Chubby And Groovy", selectedStudioName.Length > 12 ? 56 : 72, FontStyle.Bold);
            title.ForeColor = Color.White;
            title.BackColor = Color.Transparent;
            title.Size = new Size(850, 90);
            title.Location = new Point(470, 105);
            bg.Controls.Add(title);

            Label subtitle = new Label();
            subtitle.Text = "(" + selectedStudioJenis + ")";
            subtitle.Font = new Font("Georgia", 28, FontStyle.Bold);
            subtitle.ForeColor = Color.White;
            subtitle.BackColor = Color.Transparent;
            subtitle.Size = new Size(450, 50);
            subtitle.Location = new Point(480, 190);
            bg.Controls.Add(subtitle);

            AddPic(bg, Properties.Resources.Pink, 1420, 90, 190, 190);
        }

        void AddDropdownHeaderImage(Control parent, Image iconImage, string text)
        {
            PictureBox icon = new PictureBox();
            icon.Image = iconImage;
            icon.SizeMode = PictureBoxSizeMode.Zoom;
            icon.Size = new Size(55, 55);
            icon.Location = new Point(62, 32);
            icon.BackColor = Color.Transparent;
            parent.Controls.Add(icon);

            Label label = new Label();
            label.Text = text;
            label.Font = new Font("Arial", 28, FontStyle.Bold);
            label.ForeColor = DarkBlue;
            label.BackColor = Color.Transparent;
            label.Size = new Size(850, 70);
            label.Location = new Point(180, 28);
            parent.Controls.Add(label);

            Label arrow = new Label();
            arrow.Text = "⌄";
            arrow.Font = new Font("Arial", 44, FontStyle.Bold);
            arrow.ForeColor = DarkBlue;
            arrow.BackColor = Color.Transparent;
            arrow.TextAlign = ContentAlignment.MiddleCenter;
            arrow.Size = new Size(80, 80);
            arrow.Location = new Point(1190, 20);
            parent.Controls.Add(arrow);
        }

        void AddInputRowImage(Control parent, int x, int y, Image iconImage, string text, bool dropdown, EventHandler clickEvent)
        {
            Panel rowShadow = RoundedPanel(1310, 110, 30, Color.FromArgb(135, 185, 245));
            rowShadow.Location = new Point(x, y + 8);
            parent.Controls.Add(rowShadow);

            Panel row = RoundedPanel(1310, 110, 30, Color.WhiteSmoke);
            row.Location = new Point(x, y);
            row.Cursor = Cursors.Hand;
            parent.Controls.Add(row);
            row.BringToFront();

            if (clickEvent != null)
                row.Click += clickEvent;

            PictureBox icon = new PictureBox();
            icon.Image = iconImage;
            icon.SizeMode = PictureBoxSizeMode.Zoom;
            icon.Size = new Size(55, 55);
            icon.Location = new Point(62, 27);
            icon.BackColor = Color.Transparent;
            icon.Cursor = Cursors.Hand;
            row.Controls.Add(icon);

            if (clickEvent != null)
                icon.Click += clickEvent;

            Label label = new Label();
            label.Text = text;
            label.Font = new Font("Arial", 28, FontStyle.Bold);
            label.ForeColor = DarkBlue;
            label.BackColor = Color.Transparent;
            label.TextAlign = ContentAlignment.MiddleLeft;
            label.Size = new Size(900, 80);
            label.Location = new Point(180, 16);
            label.Cursor = Cursors.Hand;
            row.Controls.Add(label);

            if (clickEvent != null)
                label.Click += clickEvent;

            if (dropdown)
            {
                Label arrow = new Label();
                arrow.Text = "⌄";
                arrow.Font = new Font("Arial", 44, FontStyle.Bold);
                arrow.ForeColor = DarkBlue;
                arrow.BackColor = Color.Transparent;
                arrow.TextAlign = ContentAlignment.MiddleCenter;
                arrow.Size = new Size(80, 80);
                arrow.Location = new Point(1190, 10);
                arrow.Cursor = Cursors.Hand;
                row.Controls.Add(arrow);

                if (clickEvent != null)
                    arrow.Click += clickEvent;
            }
        }

        void AddInputRow(Control parent, int x, int y, string iconText, string text, bool dropdown, EventHandler clickEvent)
        {
            Panel rowShadow = RoundedPanel(1310, 110, 30, Color.FromArgb(135, 185, 245));
            rowShadow.Location = new Point(x, y + 8);
            parent.Controls.Add(rowShadow);

            Panel row = RoundedPanel(1310, 110, 30, Color.WhiteSmoke);
            row.Location = new Point(x, y);
            row.Cursor = Cursors.Hand;
            parent.Controls.Add(row);
            row.BringToFront();

            if (clickEvent != null)
                row.Click += clickEvent;

            Label icon = new Label();
            icon.Text = iconText;
            icon.Font = new Font("Arial", 24, FontStyle.Bold);
            icon.ForeColor = CardBlue;
            icon.BackColor = Color.Transparent;
            icon.TextAlign = ContentAlignment.MiddleCenter;
            icon.Size = new Size(110, 80);
            icon.Location = new Point(35, 15);
            row.Controls.Add(icon);

            Label label = new Label();
            label.Text = text;
            label.Font = new Font("Arial", 28, FontStyle.Bold);
            label.ForeColor = DarkBlue;
            label.BackColor = Color.Transparent;
            label.TextAlign = ContentAlignment.MiddleLeft;
            label.Size = new Size(900, 80);
            label.Location = new Point(180, 16);
            row.Controls.Add(label);
        }

        void SaveNoteIfNeeded()
        {
            if (noteBoxInput == null) return;

            string note = noteBoxInput.Text.Trim();

            if (note == "" || note == "Tinggalkan pesan")
                selectedNote = "";
            else
                selectedNote = note;
        }

        void AddSimpanButton(Control parent)
        {
            Panel simpanBtn = RoundedPanel(430, 95, 30, Yellow);
            simpanBtn.Location = new Point(700, 960);
            simpanBtn.Cursor = Cursors.Hand;
            simpanBtn.Click += (s, e) => { SaveNoteIfNeeded(); ShowStudioFormPage(); };
            parent.Controls.Add(simpanBtn);

            Label simpanText = new Label();
            simpanText.Text = "Simpan";
            simpanText.Font = new Font("Arial", 28, FontStyle.Bold);
            simpanText.ForeColor = DarkBlue;
            simpanText.BackColor = Color.Transparent;
            simpanText.TextAlign = ContentAlignment.MiddleCenter;
            simpanText.Dock = DockStyle.Fill;
            simpanText.Cursor = Cursors.Hand;
            simpanText.Click += (s, e) => { SaveNoteIfNeeded(); ShowStudioFormPage(); };
            simpanBtn.Controls.Add(simpanText);
        }

        void AddTimeButton(Control parent, string time, int x, int y)
        {
            bool isBooked = bookedTimes.Contains(time);
            bool isHold = holdTimes.Contains(time);
            bool isSelected = selectedTimes.Contains(time);

            Color buttonColor;

            if (isBooked)
                buttonColor = Color.FromArgb(220, 55, 55); // merah = sudah lunas / approve kasir
            else if (isHold)
                buttonColor = Yellow; // kuning = masih hold / belum dibayar
            else if (isSelected)
                buttonColor = SelectedGray; // abu = dipilih user saat ini
            else
                buttonColor = CardBlue; // biru = tersedia

            Panel timeBtn = RoundedPanel(245, 48, 20, buttonColor);
            timeBtn.Location = new Point(x, y);
            timeBtn.Cursor = (isBooked || isHold) ? Cursors.No : Cursors.Hand;
            parent.Controls.Add(timeBtn);

            Label timeText = new Label();
            timeText.Text = time;
            timeText.Font = new Font("Arial", 24, FontStyle.Bold);
            timeText.ForeColor = isHold ? DarkBlue : Color.White;
            timeText.BackColor = Color.Transparent;
            timeText.TextAlign = ContentAlignment.MiddleCenter;
            timeText.Dock = DockStyle.Fill;
            timeText.Cursor = (isBooked || isHold) ? Cursors.No : Cursors.Hand;
            timeBtn.Controls.Add(timeText);

            EventHandler clickAction = (s, e) =>
            {
                if (isBooked)
                {
                    MessageBox.Show("Jam " + time + " sudah dibooking dan sudah lunas.");
                    return;
                }

                if (isHold)
                {
                    MessageBox.Show("Jam " + time + " sedang di-hold, menunggu konfirmasi kasir.");
                    return;
                }

                int clickedHour = int.Parse(time.Substring(0, 2));

                if (selectedTimes.Contains(time))
                {
                    selectedTimes.Remove(time);
                    timeBtn.BackColor = CardBlue;
                    timeText.ForeColor = Color.White;
                }
                else
                {
                    if (selectedTimes.Count >= 3)
                    {
                        MessageBox.Show("Maksimal pilih 3 jam aja.");
                        return;
                    }

                    if (selectedTimes.Count > 0)
                    {
                        List<int> hours = selectedTimes.ConvertAll(t => int.Parse(t.Substring(0, 2)));
                        hours.Sort();

                        int minHour = hours[0];
                        int maxHour = hours[hours.Count - 1];

                        bool bolehPilih = clickedHour == minHour - 1 || clickedHour == maxHour + 1;

                        if (!bolehPilih)
                        {
                            MessageBox.Show("Jam harus berurutan. Misal pilih 09:00, lanjutnya cuma 10:00 dan 11:00.");
                            return;
                        }

                        int nextMin = Math.Min(minHour, clickedHour);
                        int nextMax = Math.Max(maxHour, clickedHour);

                        for (int h = nextMin; h <= nextMax; h++)
                        {
                            string cekJam = h.ToString("00") + ":00";

                            if (bookedTimes.Contains(cekJam))
                            {
                                MessageBox.Show("Tidak bisa pilih jam ini karena ada jam di tengah yang sudah dibooking.");
                                return;
                            }

                            if (holdTimes.Contains(cekJam))
                            {
                                MessageBox.Show("Tidak bisa pilih jam ini karena ada jam di tengah yang sedang di-hold.");
                                return;
                            }
                        }
                    }

                    selectedTimes.Add(time);
                    timeBtn.BackColor = SelectedGray;
                    timeText.ForeColor = Color.White;
                }

                selectedTimes.Sort();
                UpdateBuatPesananButton();
            };

            timeBtn.Click += clickAction;
            timeText.Click += clickAction;
        }

        void AddServiceButton(Control parent, string serviceName, string price, int x, int y)
        {
            Panel serviceBtn = RoundedPanel(345, 105, 25, selectedServices.Contains(serviceName) ? SelectedGray : CardBlue);
            serviceBtn.Location = new Point(x, y);
            serviceBtn.Cursor = Cursors.Hand;
            parent.Controls.Add(serviceBtn);

            Label name = new Label();
            name.Text = serviceName;
            name.Font = new Font("Arial", serviceName.Length > 12 ? 21 : 26, FontStyle.Bold);
            name.ForeColor = Color.White;
            name.BackColor = Color.Transparent;
            name.TextAlign = ContentAlignment.MiddleCenter;
            name.Size = new Size(345, 55);
            name.Location = new Point(0, 12);
            name.Cursor = Cursors.Hand;
            serviceBtn.Controls.Add(name);

            Label priceLbl = new Label();
            priceLbl.Text = price;
            priceLbl.Font = new Font("Arial", 16, FontStyle.Regular);
            priceLbl.ForeColor = Color.White;
            priceLbl.BackColor = Color.Transparent;
            priceLbl.TextAlign = ContentAlignment.MiddleCenter;
            priceLbl.Size = new Size(345, 35);
            priceLbl.Location = new Point(0, 60);
            priceLbl.Cursor = Cursors.Hand;
            serviceBtn.Controls.Add(priceLbl);

            EventHandler clickAction = (s, e) =>
            {
                if (selectedServices.Contains(serviceName))
                {
                    selectedServices.Remove(serviceName);
                    serviceBtn.BackColor = CardBlue;
                }
                else
                {
                    selectedServices.Add(serviceName);
                    serviceBtn.BackColor = SelectedGray;
                }
            };

            serviceBtn.Click += clickAction;
            name.Click += clickAction;
            priceLbl.Click += clickAction;
        }

        void AddBuatPesananButton(Control parent)
        {
            buatPesananButton = RoundedPanel(430, 95, 30, DisabledGray);
            buatPesananButton.Location = new Point(700, 960);
            buatPesananButton.Cursor = Cursors.Hand;
            buatPesananButton.Click += (s, e) => BuatPesanan();
            parent.Controls.Add(buatPesananButton);

            buatPesananText = new Label();
            buatPesananText.Text = "Buat Pesanan";
            buatPesananText.Font = new Font("Arial", 28, FontStyle.Bold);
            buatPesananText.ForeColor = Color.White;
            buatPesananText.BackColor = Color.Transparent;
            buatPesananText.TextAlign = ContentAlignment.MiddleCenter;
            buatPesananText.Dock = DockStyle.Fill;
            buatPesananText.Cursor = Cursors.Hand;
            buatPesananText.Click += (s, e) => BuatPesanan();
            buatPesananButton.Controls.Add(buatPesananText);

            UpdateBuatPesananButton();
        }

        void UpdateBuatPesananButton()
        {
            if (buatPesananButton == null || buatPesananText == null) return;

            if (selectedTimes.Count > 0)
            {
                buatPesananButton.BackColor = Yellow;
                buatPesananText.ForeColor = DarkBlue;
            }
            else
            {
                buatPesananButton.BackColor = DisabledGray;
                buatPesananText.ForeColor = Color.White;
            }
        }

        void BuatPesanan()
        {
            if (selectedTimes.Count == 0)
            {
                MessageBox.Show("Pilih waktu dulu, nge.");
                return;
            }

            ShowRincianBooking();
        }

        void ShowRincianBooking()
        {
            wrapperPanel.Controls.Clear();

            int hargaStudioPerJam = selectedStudioHarga;
            selectedTimes.Sort();
            int durasi = selectedTimes.Count;
            int subtotalStudio = hargaStudioPerJam * durasi;

            int totalLayanan = 0;

            foreach (string layanan in selectedServices)
            {
                if (servicePriceByName.ContainsKey(layanan))
                    totalLayanan += servicePriceByName[layanan] * durasi;
            }

            int total = subtotalStudio + totalLayanan;

            string waktuText = string.Join(", ", selectedTimes);
            string layananText = selectedServices.Count == 0 ? "-" : string.Join(", ", selectedServices);

            Panel bg = CreateGradientBackground();
            wrapperPanel.Controls.Add(bg);

            Label back = CreateBackButton();
            back.ForeColor = DarkBlue;
            back.Click += (s, e) => ShowStudioFormPage();
            bg.Controls.Add(back);

            Label title = new Label();
            title.Text = "Rincian Booking";
            title.Font = SafeFont("Chubby And Groovy", 72, FontStyle.Bold);
            title.ForeColor = DarkBlue;
            title.BackColor = Color.Transparent;
            title.TextAlign = ContentAlignment.MiddleCenter;
            title.Size = new Size(900, 120);
            title.Location = new Point(510, 55);
            bg.Controls.Add(title);

            Panel outerBox = RoundedPanel(1660, 760, 60, Color.FromArgb(220, 235, 252));
            outerBox.Location = new Point(130, 110);
            bg.Controls.Add(outerBox);

            Panel innerBox = RoundedPanel(1570, 680, 55, Color.WhiteSmoke);
            innerBox.Location = new Point(45, 40);
            outerBox.Controls.Add(innerBox);

            string catatanText = string.IsNullOrWhiteSpace(selectedNote) ? "-" : selectedNote;

            AddRincianRow(innerBox, "▣", "Tanggal", GetTodayDateText(), 70);
            AddRincianRow(innerBox, "◷", "Waktu", waktuText, 145);
            AddRincianRow(innerBox, "♫", "Studio", selectedStudioName + " (" + selectedStudioJenis + ")", 220);
            AddRincianRow(innerBox, "+", "Layanan Tambahan", layananText, 295);
            AddRincianRow(innerBox, "✎", "Catatan", catatanText, 370);

            AddRincianLine(innerBox, 90, 500, 1390);

            int yPos = 535;

            AddRincianText(
                innerBox,
                "Studio (" + durasi + " Jam)",
                FormatRupiah(subtotalStudio),
                yPos,
                false
            );

            yPos += 60;

            foreach (string layanan in selectedServices)
            {
                if (servicePriceByName.ContainsKey(layanan))
                {
                    int hargaLayanan = servicePriceByName[layanan] * durasi;

                    AddRincianText(
                        innerBox,
                        layanan + " (" + durasi + " Jam)",
                        FormatRupiah(hargaLayanan),
                        yPos,
                        false
                    );

                    yPos += 60;
                }
            }

            AddRincianLine(innerBox, 90, yPos + 10, 1390);

            AddRincianText(
                innerBox,
                "Total",
                FormatRupiah(total),
                yPos + 35,
                true
            );

            Panel bayarBtn = RoundedPanel(430, 95, 30, Yellow);
            bayarBtn.Location = new Point(745, 950);
            bayarBtn.Cursor = Cursors.Hand;
            bayarBtn.Click += (s, e) => KonfirmasiBayar();
            bg.Controls.Add(bayarBtn);

            Label bayarText = new Label();
            bayarText.Text = "Bayar";
            bayarText.Font = new Font("Arial", 30, FontStyle.Bold);
            bayarText.ForeColor = DarkBlue;
            bayarText.BackColor = Color.Transparent;
            bayarText.TextAlign = ContentAlignment.MiddleCenter;
            bayarText.Dock = DockStyle.Fill;
            bayarText.Cursor = Cursors.Hand;
            bayarText.Click += (s, e) => KonfirmasiBayar();
            bayarBtn.Controls.Add(bayarText);
        }

        void AddRincianRow(Control parent, string iconText, string labelText, string valueText, int y)
        {
            Label icon = new Label();
            icon.Text = iconText;
            icon.Font = new Font("Arial", 34, FontStyle.Bold);
            icon.ForeColor = CardBlue;
            icon.BackColor = Color.Transparent;
            icon.TextAlign = ContentAlignment.MiddleCenter;
            icon.Size = new Size(90, 70);
            icon.Location = new Point(120, y);
            parent.Controls.Add(icon);

            Label label = new Label();
            label.Text = labelText;
            label.Font = new Font("Arial", 24, FontStyle.Bold);
            label.ForeColor = Color.Black;
            label.BackColor = Color.Transparent;
            label.Size = new Size(520, 60);
            label.Location = new Point(260, y + 8);
            parent.Controls.Add(label);

            Label titik = new Label();
            titik.Text = ":";
            titik.Font = new Font("Arial", 24, FontStyle.Bold);
            titik.ForeColor = Color.Black;
            titik.BackColor = Color.Transparent;
            titik.Size = new Size(50, 60);
            titik.Location = new Point(980, y + 8);
            parent.Controls.Add(titik);

            Label value = new Label();
            value.Text = valueText;
            value.Font = new Font("Arial", 21, FontStyle.Bold);
            value.ForeColor = Color.Black;
            value.BackColor = Color.Transparent;
            value.Size = new Size(520, labelText == "Catatan" ? 110 : 70);
            value.Location = new Point(1030, y + 8);
            value.AutoEllipsis = false;
            value.TextAlign = ContentAlignment.TopLeft;
            parent.Controls.Add(value);
        }

        void AddRincianText(Control parent, string labelText, string valueText, int y, bool bold)
        {
            Label label = new Label();
            label.Text = labelText;
            label.Font = new Font("Arial", 24, bold ? FontStyle.Bold : FontStyle.Regular);
            label.ForeColor = Color.Black;
            label.BackColor = Color.Transparent;
            label.Size = new Size(500, 60);
            label.Location = new Point(120, y);
            parent.Controls.Add(label);

            Label titik = new Label();
            titik.Text = ":";
            titik.Font = new Font("Arial", 24, FontStyle.Bold);
            titik.ForeColor = Color.Black;
            titik.BackColor = Color.Transparent;
            titik.Size = new Size(50, 60);
            titik.Location = new Point(1080, y);
            parent.Controls.Add(titik);

            Label value = new Label();
            value.Text = valueText;
            value.Font = new Font("Arial", 24, FontStyle.Bold);
            value.ForeColor = Color.Black;
            value.BackColor = Color.Transparent;
            value.Size = new Size(420, 60);
            value.Location = new Point(1130, y);
            parent.Controls.Add(value);
        }

        void AddRincianLine(Control parent, int x, int y, int w)
        {
            Panel line = new Panel();
            line.BackColor = Color.FromArgb(220, 205, 175);
            line.Location = new Point(x, y);
            line.Size = new Size(w, 3);
            parent.Controls.Add(line);
        }

        void KonfirmasiBayar()
        {
            DialogResult result = MessageBox.Show(
                "Yakin mau buat booking sekarang?",
                "Konfirmasi Booking",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (result == DialogResult.Yes)
            {
                SimpanBookingKeDatabase();

                MessageBox.Show(
                    "Booking berhasil dibuat.\nSilahkan menuju ke kasir.",
                    "Berhasil",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information
                );

                ResetPilihanBooking();
                ShowDashboardAwal();
            }
        }

        void SimpanBookingKeDatabase()
        {
            selectedTimes.Sort();

            LoadBookedTimes();

            foreach (string jamDipilih in selectedTimes)
            {
                if (bookedTimes.Contains(jamDipilih))
                {
                    MessageBox.Show("Jam " + jamDipilih + " sudah dibooking. Silahkan pilih jam lain.");
                    return;
                }

                if (holdTimes.Contains(jamDipilih))
                {
                    MessageBox.Show("Jam " + jamDipilih + " sedang di-hold. Silahkan pilih jam lain.");
                    return;
                }
            }

            TimeSpan jamMulai = TimeSpan.Parse(selectedTimes[0]);
            TimeSpan jamTerakhir = TimeSpan.Parse(selectedTimes[selectedTimes.Count - 1]);
            TimeSpan jamSelesai = jamTerakhir.Add(TimeSpan.FromHours(1));

            int durasi = selectedTimes.Count;

            int subtotalStudio = selectedStudioHarga * durasi;
            int totalLayanan = HitungTotalLayananPerJam() * durasi;
            int totalHarga = subtotalStudio + totalLayanan;

            using (SqlConnection conn = new SqlConnection(connString))
            {
                conn.Open();

                string insertBooking = @"
        INSERT INTO Booking
        (
            nama_pemesan,
            no_hp,
            id_studio,
            tanggal,
            jam_mulai,
            jam_selesai,
            durasi,
            total_harga,
            status_booking,
            status_pembayaran,
            metode_pembayaran,
            catatan
        )
        OUTPUT INSERTED.id_booking
        VALUES
        (
            @nama,
            @nohp,
            @idstudio,
            @tanggal,
            @jammulai,
            @jamselesai,
            @durasi,
            @totalharga,
            'Dibooking',
            'Belum Lunas',
            'Cash',
            @catatan
        )";

                SqlCommand cmd = new SqlCommand(insertBooking, conn);

                cmd.Parameters.AddWithValue("@nama", "Guest");
                cmd.Parameters.AddWithValue("@nohp", "-");
                cmd.Parameters.AddWithValue("@idstudio", selectedStudioId);
                cmd.Parameters.AddWithValue("@tanggal", DateTime.Today);
                cmd.Parameters.AddWithValue("@jammulai", jamMulai);
                cmd.Parameters.AddWithValue("@jamselesai", jamSelesai);
                cmd.Parameters.AddWithValue("@durasi", durasi);
                cmd.Parameters.AddWithValue("@totalharga", totalHarga);

                if (string.IsNullOrWhiteSpace(selectedNote))
                    cmd.Parameters.AddWithValue("@catatan", DBNull.Value);
                else
                    cmd.Parameters.AddWithValue("@catatan", selectedNote);

                int idBooking = Convert.ToInt32(cmd.ExecuteScalar());

                foreach (string layanan in selectedServices)
                {
                    if (!serviceIdByName.ContainsKey(layanan))
                        continue;

                    string insertLayanan = @"
            INSERT INTO Booking_Layanan
            (
                id_booking,
                id_layanan,
                harga
            )
            VALUES
            (
                @idbooking,
                @idlayanan,
                @harga
            )";

                    SqlCommand cmdLayanan = new SqlCommand(insertLayanan, conn);

                    cmdLayanan.Parameters.AddWithValue("@idbooking", idBooking);
                    cmdLayanan.Parameters.AddWithValue("@idlayanan", serviceIdByName[layanan]);
                    cmdLayanan.Parameters.AddWithValue("@harga", servicePriceByName[layanan]);

                    cmdLayanan.ExecuteNonQuery();
                }
            }
        }

        int HitungTotalLayananPerJam()
        {
            int total = 0;

            foreach (string layanan in selectedServices)
            {
                if (servicePriceByName.ContainsKey(layanan))
                    total += servicePriceByName[layanan];
            }

            return total;
        }

        void ResetPilihanBooking()
        {
            selectedTimes.Clear();
            selectedServices.Clear();
            selectedServiceIds.Clear();
            selectedNote = "";
        }

        string FormatRupiah(int value)
        {
            return "Rp " + value.ToString("N0").Replace(",", ".");
        }

        string GetTodayDateText()
        {
            return DateTime.Now.ToString("dd/MM/yyyy");
        }

        string GetTodayDayOnly()
        {
            return DateTime.Now.ToString("dd");
        }

        void Logout()
        {
            Close();
            Form1 login = new Form1();
            login.Show();
        }

        Panel CreateGradientBackground()
        {
            Panel bg = new Panel();
            bg.Dock = DockStyle.Fill;
            bg.BackColor = BlueTop;

            bg.Paint += (s, e) =>
            {
                e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;

                using (LinearGradientBrush brush = new LinearGradientBrush(
                    bg.ClientRectangle,
                    BlueBottom,
                    BlueTop,
                    LinearGradientMode.ForwardDiagonal))
                {
                    e.Graphics.FillRectangle(brush, bg.ClientRectangle);
                }
            };

            return bg;
        }

        Label CreateBackButton()
        {
            Label back = new Label();
            back.Text = "‹";
            back.Font = new Font("Arial", 48, FontStyle.Regular);
            back.ForeColor = DarkBlue;
            back.AutoSize = true;
            back.Location = new Point(35, 25);
            back.Cursor = Cursors.Hand;
            back.BackColor = Color.Transparent;
            return back;
        }

        void AddPic(Control parent, Image img, int x, int y, int w, int h)
        {
            PictureBox pic = new PictureBox();
            pic.Image = img;
            pic.Location = new Point(x, y);
            pic.Size = new Size(w, h);
            pic.SizeMode = PictureBoxSizeMode.Zoom;
            pic.BackColor = Color.Transparent;
            parent.Controls.Add(pic);
            pic.BringToFront();
        }

        void AddSparkle(Control parent, int x, int y, int size)
        {
            Label sparkle = new Label();
            sparkle.Text = "✦";
            sparkle.Font = new Font("Arial", size, FontStyle.Bold);
            sparkle.ForeColor = Color.Black;
            sparkle.BackColor = Color.Transparent;
            sparkle.AutoSize = true;
            sparkle.Location = new Point(x, y);
            parent.Controls.Add(sparkle);
            sparkle.BringToFront();
        }

        void AddLabel(Control p, string text, int x, int y, int size, bool bold, Color color)
        {
            Label lbl = new Label();
            lbl.Text = text;
            lbl.Font = new Font("Segoe UI", size, bold ? FontStyle.Bold : FontStyle.Regular);
            lbl.ForeColor = color;
            lbl.AutoSize = true;
            lbl.BackColor = Color.Transparent;
            lbl.Location = new Point(x, y);
            p.Controls.Add(lbl);
        }

        Panel RoundedPanel(int w, int h, int r, Color color)
        {
            Panel p = new Panel();
            p.Size = new Size(w, h);
            p.BackColor = color;

            GraphicsPath path = new GraphicsPath();
            path.AddArc(0, 0, r * 2, r * 2, 180, 90);
            path.AddArc(w - r * 2, 0, r * 2, r * 2, 270, 90);
            path.AddArc(w - r * 2, h - r * 2, r * 2, r * 2, 0, 90);
            path.AddArc(0, h - r * 2, r * 2, r * 2, 90, 90);
            path.CloseFigure();

            p.Region = new Region(path);
            return p;
        }

        Font SafeFont(string fontName, int size, FontStyle style)
        {
            try
            {
                return new Font(fontName, size, style);
            }
            catch
            {
                return new Font("Arial", size, style);
            }
        }

        class StudioData
        {
            public int Id;
            public string Nama;
            public string Jenis;
            public int Harga;
            public string Foto;
        }

        private void DashboardGuest_Load_1(object sender, EventArgs e)
        {

        }
    }
}